import { S as SELF_ENTITY_ID, m as initialsFor, A as resolve, e as canonicalValue, B as isEncrypted, u as vaultCrypto } from './vault-crypto-BP82NYQF.js';

const DEFAULT_SETTINGS = {
  ollamaUrl: "http://localhost:11434",
  llmModel: "qwen3:8b",
  embeddingModel: "nomic-embed-text",
  visionModel: "qwen3-vl:8b",
  pdfParser: "liteparse",
  autoFillPrompt: true,
  appLockMinutes: 5,
  requireUnlockForSensitive: true,
  hasMasterPassword: false,
  globalShortcut: "CommandOrControl+Alt+O",
  shortcutEdge: "left",
  showFloatingShortcut: true,
  launchAtLogin: true
};
async function ensureSelfEntity(storage) {
  const all = await storage.listEntities();
  const existing = all.find((e) => e.id === SELF_ENTITY_ID);
  if (existing) return existing;
  const self = {
    id: SELF_ENTITY_ID,
    name: "Self",
    relationship: "self",
    initials: "ME",
    createdAt: Date.now()
  };
  await storage.saveEntity(self);
  return self;
}
async function resolveOrCreateEntity(storage, name, relationshipHint) {
  const all = await storage.listEntities();
  const candidateTokens = tokenize(name);
  if (candidateTokens.length === 0) {
    const self = all.find((e) => e.id === SELF_ENTITY_ID);
    if (self) return self;
  }
  const exact = all.find((e) => normalize(e.name) === normalize(name));
  if (exact) return exact;
  let best = null;
  for (const e of all) {
    const eTokens = tokenize(e.name);
    if (eTokens.length === 0) continue;
    const score = tokenOverlapScore(candidateTokens, eTokens);
    if (score >= 0.66 && (!best || score > best.score)) best = { entity: e, score };
  }
  if (best) return best.entity;
  const entity = {
    id: crypto.randomUUID(),
    name: name.trim(),
    relationship: relationshipHint ?? "other",
    initials: initialsFor(name),
    createdAt: Date.now()
  };
  await storage.saveEntity(entity);
  return entity;
}
function normalize(s) {
  return s.trim().toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
}
function tokenize(s) {
  return normalize(s).split(" ").filter((t) => t.length >= 2);
}
function tokenOverlapScore(a, b) {
  const setA = new Set(a);
  const setB = new Set(b);
  let shared = 0;
  for (const t of setA) if (setB.has(t)) shared++;
  const min = Math.min(setA.size, setB.size);
  return min === 0 ? 0 : shared / min;
}
async function addCandidates(storage, candidates) {
  if (candidates.length === 0) return;
  const entityId = candidates[0].entityId;
  const byKey = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    if (c.entityId !== entityId) throw new Error("addCandidates: mixed entity ids");
    const arr = byKey.get(c.fieldKey) ?? [];
    arr.push(c);
    byKey.set(c.fieldKey, arr);
  }
  for (const [key, newOnes] of byKey) {
    const existing = await storage.getRecord(entityId, key);
    const merged = existing ? { ...existing, candidates: [...existing.candidates, ...newOnes] } : { key, candidates: newOnes, canonicalId: null, conflictState: "none" };
    await storage.setRecord(entityId, resolve(merged));
  }
}
async function pinCandidate(storage, entityId, key, candidateId) {
  const record = await storage.getRecord(entityId, key);
  if (!record) return;
  const next = {
    ...record,
    candidates: record.candidates.map((c) => ({ ...c, userPinned: c.id === candidateId }))
  };
  await storage.setRecord(entityId, resolve(next));
}
async function dismissCandidate(storage, entityId, key, candidateId) {
  const record = await storage.getRecord(entityId, key);
  if (!record) return;
  const next = {
    ...record,
    candidates: record.candidates.map(
      (c) => c.id === candidateId ? { ...c, dismissedAt: Date.now() } : c
    )
  };
  await storage.setRecord(entityId, resolve(next));
}
async function addUserCandidate(storage, entityId, key, value, normalize2) {
  const candidate = {
    id: crypto.randomUUID(),
    entityId,
    fieldKey: key,
    value: value.trim(),
    normalizedValue: normalize2(key, value),
    confidence: "high",
    source: { documentId: "user-entered" },
    docType: "unknown",
    extractedAt: Date.now(),
    userEdited: true,
    userPinned: true
  };
  await addCandidates(storage, [candidate]);
}
async function addDocumentSourceToField(storage, entityId, key, documentId) {
  const [record, doc] = await Promise.all([
    storage.getRecord(entityId, key),
    storage.getDocument(documentId)
  ]);
  if (!record || !doc) return;
  const canonical = canonicalValue(record);
  if (!canonical) return;
  if (record.candidates.some((c) => !c.dismissedAt && c.source.documentId === documentId)) return;
  const candidate = {
    id: crypto.randomUUID(),
    entityId,
    fieldKey: key,
    value: canonical.value,
    normalizedValue: canonical.normalizedValue,
    confidence: "medium",
    source: { documentId },
    docType: doc.docType,
    extractedAt: Date.now(),
    userEdited: true
  };
  await addCandidates(storage, [candidate]);
}
async function mergeEntities(storage, sourceEntityId, targetEntityId) {
  if (!sourceEntityId || !targetEntityId || sourceEntityId === targetEntityId) return;
  if (sourceEntityId === SELF_ENTITY_ID) throw new Error("Cannot merge Self into another entity");
  const sourceProfile = await storage.getProfile(sourceEntityId);
  for (const record of Object.values(sourceProfile)) {
    if (!record) continue;
    const moved = record.candidates.map((c) => ({ ...c, entityId: targetEntityId }));
    await addCandidates(storage, moved);
    await storage.deleteRecord(sourceEntityId, record.key);
  }
  for (const doc of await storage.listDocuments()) {
    if (doc.entityId === sourceEntityId) {
      await storage.saveDocument({ ...doc, entityId: targetEntityId });
    }
  }
  for (const record of await storage.listEducation(sourceEntityId)) {
    await storage.deleteEducation(record.id);
    await storage.saveEducation({ ...record, entityId: targetEntityId });
  }
  for (const record of await storage.listExperience(sourceEntityId)) {
    await storage.deleteExperience(record.id);
    await storage.saveExperience({ ...record, entityId: targetEntityId });
  }
  const embeddings = await storage.listEmbeddings();
  const movedEmbeddings = embeddings.filter((e) => e.entityId === sourceEntityId).map((e) => ({ ...e, entityId: targetEntityId }));
  if (movedEmbeddings.length) await storage.saveEmbeddings(movedEmbeddings);
  for (const rel of await storage.listRelationships()) {
    if (rel.fromEntityId !== sourceEntityId && rel.toEntityId !== sourceEntityId) continue;
    const next = {
      ...rel,
      fromEntityId: rel.fromEntityId === sourceEntityId ? targetEntityId : rel.fromEntityId,
      toEntityId: rel.toEntityId === sourceEntityId ? targetEntityId : rel.toEntityId,
      updatedAt: Date.now()
    };
    if (next.fromEntityId === next.toEntityId) await storage.deleteRelationship(rel.id);
    else await storage.saveRelationship(next);
  }
  for (const event of await storage.listEvents()) {
    if (!event.participants.some((p) => p.entityId === sourceEntityId)) continue;
    const participants = event.participants.map((p) => ({
      ...p,
      entityId: p.entityId === sourceEntityId ? targetEntityId : p.entityId
    }));
    const deduped = participants.filter(
      (p, i) => participants.findIndex((q) => q.entityId === p.entityId && q.role === p.role) === i
    );
    await storage.saveEvent({ ...event, participants: deduped, updatedAt: Date.now() });
  }
  await storage.deleteEntity(sourceEntityId);
}

function promisifyRequest(request) {
    return new Promise((resolve, reject) => {
        // @ts-ignore - file size hacks
        request.oncomplete = request.onsuccess = () => resolve(request.result);
        // @ts-ignore - file size hacks
        request.onabort = request.onerror = () => reject(request.error);
    });
}
function createStore(dbName, storeName) {
    let dbp;
    const getDB = () => {
        if (dbp)
            return dbp;
        const request = indexedDB.open(dbName);
        request.onupgradeneeded = () => request.result.createObjectStore(storeName);
        dbp = promisifyRequest(request);
        dbp.then((db) => {
            // It seems like Safari sometimes likes to just close the connection.
            // It's supposed to fire this event when that happens. Let's hope it does!
            db.onclose = () => (dbp = undefined);
        }, () => { });
        return dbp;
    };
    return (txMode, callback) => getDB().then((db) => callback(db.transaction(storeName, txMode).objectStore(storeName)));
}
let defaultGetStoreFunc;
function defaultGetStore() {
    if (!defaultGetStoreFunc) {
        defaultGetStoreFunc = createStore('keyval-store', 'keyval');
    }
    return defaultGetStoreFunc;
}
/**
 * Get a value by its key.
 *
 * @param key
 * @param customStore Method to get a custom store. Use with caution (see the docs).
 */
function get(key, customStore = defaultGetStore()) {
    return customStore('readonly', (store) => promisifyRequest(store.get(key)));
}
/**
 * Set a value with a key.
 *
 * @param key
 * @param value
 * @param customStore Method to get a custom store. Use with caution (see the docs).
 */
function set(key, value, customStore = defaultGetStore()) {
    return customStore('readwrite', (store) => {
        store.put(value, key);
        return promisifyRequest(store.transaction);
    });
}
/**
 * Delete a particular key from the store.
 *
 * @param key
 * @param customStore Method to get a custom store. Use with caution (see the docs).
 */
function del(key, customStore = defaultGetStore()) {
    return customStore('readwrite', (store) => {
        store.delete(key);
        return promisifyRequest(store.transaction);
    });
}
function eachCursor(store, callback) {
    store.openCursor().onsuccess = function () {
        if (!this.result)
            return;
        callback(this.result);
        this.result.continue();
    };
    return promisifyRequest(store.transaction);
}
/**
 * Get all keys in the store.
 *
 * @param customStore Method to get a custom store. Use with caution (see the docs).
 */
function keys(customStore = defaultGetStore()) {
    return customStore('readonly', (store) => {
        // Fast path for modern browsers
        if (store.getAllKeys) {
            return promisifyRequest(store.getAllKeys());
        }
        const items = [];
        return eachCursor(store, (cursor) => items.push(cursor.key)).then(() => items);
    });
}

const docStore = createStore("octovault-docs", "documents");
const recordStore = createStore("octovault-records", "fields");
const entityStore = createStore("octovault-entities", "entities");
const embedStore = createStore("octovault-embeddings", "vectors");
const eduStore = createStore("octovault-education", "records");
const expStore = createStore("octovault-experience", "records");
const relStore = createStore("octovault-relationships", "edges");
const eventStore = createStore("octovault-events", "events");
const settingsStore = createStore("octovault-settings", "kv");
const authStore = createStore("octovault-auth", "kv");
function recordKey(entityId, fieldKey) {
  return `${entityId}|${fieldKey}`;
}
async function putValue(store, key, value) {
  if (vaultCrypto.isUnlocked()) {
    const ct = await vaultCrypto.encryptString(JSON.stringify(value));
    await set(key, ct, store);
  } else {
    await set(key, value, store);
  }
}
async function getValue(store, key) {
  const raw = await get(key, store);
  if (raw == null) return void 0;
  if (isEncrypted(raw)) {
    if (!vaultCrypto.isUnlocked()) throw new Error("Vault is locked");
    return JSON.parse(await vaultCrypto.decryptString(raw));
  }
  return raw;
}
const indexedDbAdapter = {
  // --- Entities ---
  async listEntities() {
    const ids = await keys(entityStore);
    const ents = await Promise.all(ids.map((k) => getValue(entityStore, k)));
    return ents.filter((e) => !!e).sort((a, b) => a.createdAt - b.createdAt);
  },
  async saveEntity(entity) {
    await putValue(entityStore, entity.id, entity);
  },
  // --- Embeddings ---
  async listEmbeddings() {
    const ids = await keys(embedStore);
    const recs = await Promise.all(ids.map((k) => getValue(embedStore, k)));
    return recs.filter((r) => !!r);
  },
  async saveEmbeddings(records) {
    for (const r of records) await putValue(embedStore, r.id, r);
  },
  async deleteEmbeddingsForDoc(documentId) {
    const ids = await keys(embedStore);
    for (const id of ids) {
      const r = await getValue(embedStore, id);
      if (r?.documentId === documentId) await del(id, embedStore);
    }
  },
  // --- Education ---
  async listEducation(entityId) {
    const ids = await keys(eduStore);
    const recs = await Promise.all(ids.map((k) => getValue(eduStore, k)));
    return recs.filter((r) => !!r && r.entityId === entityId && !r.dismissedAt).sort((a, b) => (b.endDate ?? "").localeCompare(a.endDate ?? ""));
  },
  async saveEducation(record) {
    await putValue(eduStore, record.id, record);
  },
  async deleteEducation(id) {
    await del(id, eduStore);
  },
  // --- Experience ---
  async listExperience(entityId) {
    const ids = await keys(expStore);
    const recs = await Promise.all(ids.map((k) => getValue(expStore, k)));
    return recs.filter((r) => !!r && r.entityId === entityId && !r.dismissedAt).sort((a, b) => (b.endDate ?? "9999").localeCompare(a.endDate ?? "9999"));
  },
  async saveExperience(record) {
    await putValue(expStore, record.id, record);
  },
  async deleteExperience(id) {
    await del(id, expStore);
  },
  async deleteRecordsFromDoc(documentId) {
    for (const store of [eduStore, expStore, relStore, eventStore]) {
      const ids = await keys(store);
      for (const id of ids) {
        const r = await getValue(store, id);
        if (r?.source?.documentId === documentId) await del(id, store);
      }
    }
  },
  // --- Relationships ---
  async listRelationships() {
    const ids = await keys(relStore);
    const recs = await Promise.all(ids.map((k) => getValue(relStore, k)));
    return recs.filter((r) => !!r);
  },
  async saveRelationship(rel) {
    await putValue(relStore, rel.id, { ...rel, updatedAt: Date.now() });
  },
  async deleteRelationship(id) {
    await del(id, relStore);
  },
  // --- Events ---
  async listEvents() {
    const ids = await keys(eventStore);
    const recs = await Promise.all(ids.map((k) => getValue(eventStore, k)));
    return recs.filter((r) => !!r);
  },
  async saveEvent(event) {
    await putValue(eventStore, event.id, { ...event, updatedAt: Date.now() });
  },
  async deleteEvent(id) {
    await del(id, eventStore);
  },
  async deleteEventsFromDoc(documentId) {
    const ids = await keys(eventStore);
    for (const id of ids) {
      const e = await getValue(eventStore, id);
      if (e?.source?.documentId === documentId) await del(id, eventStore);
    }
  },
  async deleteEntity(id) {
    await del(id, entityStore);
    const docIds = await keys(docStore);
    for (const k of docIds) {
      const d = await getValue(docStore, k);
      if (d?.entityId === id) await del(k, docStore);
    }
    const recKeys = await keys(recordStore);
    for (const k of recKeys) {
      if (k.startsWith(`${id}|`)) await del(k, recordStore);
    }
    for (const store of [eduStore, expStore]) {
      const ids = await keys(store);
      for (const recId of ids) {
        const r = await getValue(store, recId);
        if (r?.entityId === id) await del(recId, store);
      }
    }
    const relIds = await keys(relStore);
    for (const relId of relIds) {
      const r = await getValue(relStore, relId);
      if (r && (r.fromEntityId === id || r.toEntityId === id)) {
        await del(relId, relStore);
      }
    }
  },
  // --- Documents ---
  async saveDocument(doc) {
    await putValue(docStore, doc.id, doc);
  },
  async listDocuments() {
    const ids = await keys(docStore);
    const docs = await Promise.all(ids.map((k) => getValue(docStore, k)));
    return docs.filter((d) => !!d).sort((a, b) => b.importedAt - a.importedAt);
  },
  async getDocument(id) {
    return getValue(docStore, id);
  },
  async deleteDocument(id) {
    await del(id, docStore);
  },
  // --- Records ---
  async getRecord(entityId, key) {
    return getValue(recordStore, recordKey(entityId, key));
  },
  async setRecord(entityId, record) {
    await putValue(recordStore, recordKey(entityId, record.key), record);
  },
  async deleteRecord(entityId, key) {
    await del(recordKey(entityId, key), recordStore);
  },
  async getProfile(entityId) {
    const ks = await keys(recordStore);
    const out = {};
    for (const k of ks) {
      if (!k.startsWith(`${entityId}|`)) continue;
      const r = await getValue(recordStore, k);
      if (r) out[r.key] = r;
    }
    return out;
  },
  async getAllProfiles() {
    const ks = await keys(recordStore);
    const out = {};
    for (const k of ks) {
      const sep = k.indexOf("|");
      if (sep < 0) continue;
      const entityId = k.slice(0, sep);
      const r = await getValue(recordStore, k);
      if (!r) continue;
      (out[entityId] ??= {})[r.key] = r;
    }
    return out;
  },
  async clearProfile(entityId) {
    const ks = await keys(recordStore);
    for (const k of ks) {
      if (k.startsWith(`${entityId}|`)) await del(k, recordStore);
    }
  },
  async deleteCandidatesFromDoc(documentId) {
    const ks = await keys(recordStore);
    for (const k of ks) {
      const r = await getValue(recordStore, k);
      if (!r) continue;
      const filtered = r.candidates.filter((c) => c.source.documentId !== documentId);
      if (filtered.length === 0) await del(k, recordStore);
      else if (filtered.length !== r.candidates.length) {
        await putValue(recordStore, k, { ...r, candidates: filtered, canonicalId: null });
      }
    }
  },
  // --- Settings (plain — needed before unlock) ---
  async getSettings() {
    const stored = await get("settings", settingsStore) ?? {};
    return { ...DEFAULT_SETTINGS, ...stored };
  },
  async updateSettings(patch) {
    const next = { ...await this.getSettings(), ...patch };
    await set("settings", next, settingsStore);
    return next;
  },
  // --- Auth blob (plain by definition — it's the unlock credential) ---
  async getAuthBlob() {
    return await get("blob", authStore) ?? null;
  },
  async setAuthBlob(blob) {
    await set("blob", blob, authStore);
  },
  /** Used by the "Reset vault" flow — wipes the auth credential entirely
      so getAuthBlob() returns null afterwards. */
  async deleteAuthBlob() {
    await del("blob", authStore);
  }
};

const BRIDGE_URL = "http://127.0.0.1:53117";
async function bridgeReachable() {
  try {
    const r = await fetch(`${BRIDGE_URL}/health`, { method: "GET" });
    return r.ok;
  } catch {
    return false;
  }
}
async function fetchProfileFromBridge() {
  try {
    const r = await fetch(`${BRIDGE_URL}/profile`);
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

export { DEFAULT_SETTINGS as D, addUserCandidate as a, bridgeReachable as b, addCandidates as c, dismissCandidate as d, ensureSelfEntity as e, fetchProfileFromBridge as f, addDocumentSourceToField as g, indexedDbAdapter as i, mergeEntities as m, pinCandidate as p, resolveOrCreateEntity as r };
//# sourceMappingURL=bridge-Cc9R8awV.js.map
