import './vault-crypto-BP82NYQF.js';
import { i as isLikelyOpenField } from './generate-91Ccbizt.js';

const FIELD_ATTR = "data-octovault-id";
function collectCandidates(root, sink) {
  const selector = "input, select, textarea, [contenteditable=''], [contenteditable='true'], [role='textbox'], [role='combobox']";
  const found = root.querySelectorAll(selector);
  for (const el of found) sink.push(el);
  const all = root.querySelectorAll("*");
  for (const el of all) {
    if (el.shadowRoot) collectCandidates(el.shadowRoot, sink);
  }
}
const NEVER_FILL_NAME_RE = /\b(g-recaptcha-response|h-captcha-response|cf-turnstile-response|recaptcha|captcha|honey?pot)\b/i;
function isFillableType(el) {
  const name = el.getAttribute("name") ?? "";
  if (name && NEVER_FILL_NAME_RE.test(name)) return false;
  const id = el.getAttribute("id") ?? "";
  if (id && NEVER_FILL_NAME_RE.test(id)) return false;
  if (el instanceof HTMLInputElement) {
    const type = el.type;
    if (["hidden", "submit", "button", "reset", "image", "file", "password"].includes(type)) return false;
    return true;
  }
  if (el instanceof HTMLSelectElement || el instanceof HTMLTextAreaElement) return true;
  const role = el.getAttribute("role");
  const editable = el.isContentEditable;
  if (editable) return true;
  if (role === "textbox" || role === "combobox") return true;
  return false;
}
function isInteractable(el) {
  if ("disabled" in el && el.disabled) return false;
  if ("readOnly" in el && el.readOnly) return false;
  if (el.getAttribute("aria-disabled") === "true") return false;
  if (el.getAttribute("aria-readonly") === "true") return false;
  if (el.getAttribute("contenteditable") === "false") return false;
  return true;
}
function isHidden(el) {
  const rect = el.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return true;
  const style = window.getComputedStyle(el);
  if (style.visibility === "hidden" || style.display === "none") return true;
  return false;
}
function fieldType(el) {
  if (el instanceof HTMLInputElement) return el.type || "text";
  if (el instanceof HTMLSelectElement) return "select";
  if (el instanceof HTMLTextAreaElement) return "textarea";
  return "text";
}
function detectFields() {
  const out = [];
  const candidates = [];
  collectCandidates(document, candidates);
  let i = 0;
  for (const el of candidates) {
    if (!isFillableType(el)) continue;
    if (!isInteractable(el)) continue;
    const type = fieldType(el);
    const id = `ov-${i++}`;
    el.setAttribute(FIELD_ATTR, id);
    out.push({
      el,
      field: {
        id,
        type,
        label: findLabel(el),
        name: el.getAttribute("name") || el.getAttribute("id") || "",
        placeholder: el.placeholder ?? el.getAttribute("aria-placeholder") ?? "",
        autocomplete: el.getAttribute("autocomplete") ?? "",
        section: findSection(el),
        hidden: isHidden(el)
      }
    });
  }
  return out;
}
function stripOptionsFromQuestion(text, options) {
  let out = cleanLabel(text);
  for (const opt of options.filter(Boolean).sort((a, b) => b.length - a.length)) {
    out = out.replaceAll(opt, "");
  }
  return cleanLabel(out);
}
function findGroupLabel(els, options) {
  for (const r of els) {
    const fs = r.closest("fieldset");
    if (fs) {
      const legend = fs.querySelector(":scope > legend");
      const txt = legend?.textContent?.trim();
      if (txt) return cleanLabel(txt);
      const fromFieldset = stripOptionsFromQuestion(directText(fs) || fs.textContent?.trim() || "", options);
      if (fromFieldset) return fromFieldset;
    }
    let parent = r.parentElement;
    while (parent) {
      const role = parent.getAttribute("role");
      const aria = parent.getAttribute("aria-label")?.trim();
      if ((role === "radiogroup" || role === "group") && aria) return cleanLabel(aria);
      const lb = parent.getAttribute("aria-labelledby");
      if ((role === "radiogroup" || role === "group") && lb) {
        const ref = parent.ownerDocument.getElementById(lb.split(/\s+/)[0]);
        const txt = ref ? directText(ref) || ref.textContent?.trim() : "";
        if (txt) return cleanLabel(txt);
      }
      parent = parent.parentElement;
    }
  }
  const common = els[0].parentElement;
  if (common) {
    let prev = common.previousElementSibling;
    while (prev) {
      const tag = prev.tagName.toLowerCase();
      if (["h1", "h2", "h3", "h4", "h5", "h6", "label", "p", "legend"].includes(tag)) {
        const t = directText(prev) || prev.textContent?.trim() || "";
        if (t) return cleanLabel(t);
      }
      prev = prev.previousElementSibling;
    }
  }
  return cleanLabel(findSection(els[0])) || "Choice";
}
function detectRadioGroups(detected) {
  const byName = /* @__PURE__ */ new Map();
  const containerKeys = /* @__PURE__ */ new WeakMap();
  let containerSeq = 0;
  const keyForRadio = (el, field) => {
    if (el.name) return `name:${el.name}`;
    const container = el.closest("[role='radiogroup'], fieldset, [role='group']");
    if (container) {
      const existing = containerKeys.get(container);
      if (existing) return existing;
      const key = `container:${containerSeq++}`;
      containerKeys.set(container, key);
      return key;
    }
    return `label:${field.section ?? ""}:${field.label}`;
  };
  for (const d of detected) {
    if (!(d.el instanceof HTMLInputElement) || d.el.type !== "radio") continue;
    const key = keyForRadio(d.el, d.field);
    const arr = byName.get(key) ?? [];
    arr.push({ el: d.el, field: d.field });
    byName.set(key, arr);
  }
  const groups = [];
  let i = 0;
  for (const [, members] of byName) {
    const els = members.map((m) => m.el);
    const options = members.map((m) => m.field.label || m.el.value || "");
    const syntheticId = `ov-rgroup-${i++}`;
    groups.push({
      syntheticId,
      field: {
        id: syntheticId,
        type: "radio",
        label: findGroupLabel(els, options),
        name: els[0].name ?? "",
        placeholder: "",
        autocomplete: "",
        section: members[0].field.section
      },
      options,
      parts: els
    });
  }
  return groups;
}
function detectCheckboxGroups(detected) {
  const byKey = /* @__PURE__ */ new Map();
  const containerKeys = /* @__PURE__ */ new WeakMap();
  let containerSeq = 0;
  const keyForCheckbox = (el, field) => {
    if (el.name) return `name:${el.name}`;
    const container = el.closest("fieldset, [role='group'], [aria-labelledby]");
    if (container) {
      const existing = containerKeys.get(container);
      if (existing) return existing;
      const key = `container:${containerSeq++}`;
      containerKeys.set(container, key);
      return key;
    }
    return `label:${field.section ?? ""}:${field.label}`;
  };
  for (const d of detected) {
    if (!(d.el instanceof HTMLInputElement) || d.el.type !== "checkbox") continue;
    if (d.field.hidden) continue;
    const key = keyForCheckbox(d.el, d.field);
    const arr = byKey.get(key) ?? [];
    arr.push({ el: d.el, field: d.field });
    byKey.set(key, arr);
  }
  const groups = [];
  let i = 0;
  for (const [, members] of byKey) {
    if (members.length < 2) continue;
    const els = members.map((m) => m.el);
    const options = members.map((m) => m.field.label || m.el.value || "").filter(Boolean);
    const syntheticId = `ov-cgroup-${i++}`;
    groups.push({
      syntheticId,
      field: {
        id: syntheticId,
        type: "checkbox",
        label: findGroupLabel(els, options),
        name: els[0].name ?? "",
        placeholder: "",
        autocomplete: "",
        section: members[0].field.section
      },
      options,
      parts: els
    });
  }
  return groups;
}
function labelOfPart(el) {
  const aria = (el.getAttribute("aria-label") ?? "").toLowerCase();
  const name = (el.getAttribute("name") ?? "").toLowerCase();
  const label = findLabel(el).toLowerCase();
  return `${aria} ${name} ${label}`.trim();
}
function classifyDatePart(el) {
  const t = labelOfPart(el);
  if (/\byear|yyyy|yy\b|\bann[eé]e\b|वर्ष/.test(t)) return "year";
  if (/\bmonth|mm\b|mois|माह/.test(t)) return "month";
  if (/\bday|dd\b|jour|दिन/.test(t)) return "day";
  if (el instanceof HTMLSelectElement) {
    const opts = Array.from(el.options).slice(1, 5).map((o) => o.textContent?.trim() ?? "");
    if (opts.length && opts.every((o) => /^\d{4}$/.test(o))) return "year";
    if (el.options.length >= 12 && el.options.length <= 13) {
      if (opts.some((o) => /january|jan|february|feb|march|april/i.test(o))) return "month";
    }
    if (opts.length && opts.every((o) => /^\d{1,2}$/.test(o))) {
      const max = Math.max(...Array.from(el.options).map((o) => parseInt(o.textContent ?? "0", 10)));
      if (max <= 31) return "day";
    }
  }
  return null;
}
function detectDateComposites(detected) {
  const bySection = /* @__PURE__ */ new Map();
  for (const d of detected) {
    if (!(d.el instanceof HTMLSelectElement)) continue;
    const part = classifyDatePart(d.el);
    if (!part) continue;
    const sec = d.field.section ?? "";
    const arr = bySection.get(sec) ?? [];
    arr.push({ el: d.el, field: d.field, part });
    bySection.set(sec, arr);
  }
  const composites = [];
  let i = 0;
  for (const [sec, parts] of bySection) {
    const year = parts.find((p) => p.part === "year")?.el;
    const month = parts.find((p) => p.part === "month")?.el;
    const day = parts.find((p) => p.part === "day")?.el;
    if (!year || !month || !day) continue;
    const syntheticId = `ov-comp-${i++}`;
    composites.push({
      syntheticId,
      field: {
        id: syntheticId,
        type: "date",
        label: sec || "Date",
        name: "",
        placeholder: "",
        autocomplete: "",
        section: sec || void 0
      },
      parts: { year, month, day }
    });
  }
  return composites;
}
const MONTH_NAMES = {
  jan: 1,
  january: 1,
  feb: 2,
  february: 2,
  mar: 3,
  march: 3,
  apr: 4,
  april: 4,
  may: 5,
  jun: 6,
  june: 6,
  jul: 7,
  july: 7,
  aug: 8,
  august: 8,
  sep: 9,
  sept: 9,
  september: 9,
  oct: 10,
  october: 10,
  nov: 11,
  november: 11,
  dec: 12,
  december: 12
};
function pad(n) {
  return String(n).padStart(2, "0");
}
function toIso(y, m, d) {
  return `${y}-${pad(m)}-${pad(d)}`;
}
function parseIntentDates(intent) {
  if (!intent || intent.trim().length === 0) return {};
  const text = intent.trim();
  const out = {};
  const iso = text.match(/(\d{4})-(\d{2})-(\d{2})\s*(?:to|-|–|—|until)\s*(\d{4})-(\d{2})-(\d{2})/i);
  if (iso) {
    out.start = `${iso[1]}-${iso[2]}-${iso[3]}`;
    out.end = `${iso[4]}-${iso[5]}-${iso[6]}`;
    return out;
  }
  const isoSingle = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (isoSingle) out.start = `${isoSingle[1]}-${isoSingle[2]}-${isoSingle[3]}`;
  const monthRange = text.match(/\b([A-Za-z]{3,9})\s+(\d{1,2})\s*(?:to|-|–|—|until)\s*(?:([A-Za-z]{3,9})\s+)?(\d{1,2}),?\s+(\d{4})\b/i);
  if (monthRange) {
    const m1 = MONTH_NAMES[monthRange[1].toLowerCase()];
    const m2 = monthRange[3] ? MONTH_NAMES[monthRange[3].toLowerCase()] : m1;
    const y = parseInt(monthRange[5], 10);
    if (m1 && m2) {
      out.start = toIso(y, m1, parseInt(monthRange[2], 10));
      out.end = toIso(y, m2, parseInt(monthRange[4], 10));
      return out;
    }
  }
  const monthOnly = text.match(/\b([A-Za-z]{3,9})\s+(\d{4})\b/i);
  if (monthOnly && !out.start) {
    const m = MONTH_NAMES[monthOnly[1].toLowerCase()];
    const y = parseInt(monthOnly[2], 10);
    if (m) out.start = toIso(y, m, 1);
  }
  const dur = text.match(/\b(\d{1,3})\s*[-\s]?day\b/i);
  if (dur && out.start && !out.end) {
    const n = parseInt(dur[1], 10);
    if (n > 0 && n < 365) {
      const [y, m, d] = out.start.split("-").map(Number);
      const start = new Date(Date.UTC(y, m - 1, d));
      const end = new Date(start.getTime() + (n - 1) * 864e5);
      out.end = toIso(end.getUTCFullYear(), end.getUTCMonth() + 1, end.getUTCDate());
    }
  }
  return out;
}
function pickIntentDateForComposite(label, parsed) {
  const l = label.toLowerCase();
  if (/\b(leave|depart|exit|end|return|until|to)\b/.test(l)) return parsed.end ?? parsed.start;
  return parsed.start ?? parsed.end;
}
function fillDateComposite(parts, iso) {
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const [, yyyy, mm, dd] = m;
  const setSelectByText = (el, candidates) => {
    if (!(el instanceof HTMLSelectElement)) return false;
    for (const cand of candidates) {
      const found = Array.from(el.options).find(
        (o) => o.value === cand || o.textContent?.trim().toLowerCase() === cand.toLowerCase()
      );
      if (found) {
        el.value = found.value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
    }
    return false;
  };
  const monthNamesLong = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  const monthNamesShort = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  const monthIdx = parseInt(mm, 10) - 1;
  const dayInt = parseInt(dd, 10);
  const yearOk = setSelectByText(parts.year, [yyyy]);
  const monthOk = setSelectByText(parts.month, [mm, String(parseInt(mm, 10)), monthNamesLong[monthIdx] ?? "", monthNamesShort[monthIdx] ?? ""]);
  const dayOk = setSelectByText(parts.day, [dd, String(dayInt)]);
  return yearOk && monthOk && dayOk;
}
function detectSuspicious(detectedEls) {
  const out = [];
  let i = 0;
  const labelled = document.querySelectorAll("[aria-labelledby], [aria-label]");
  for (const el of labelled) {
    if (detectedEls.has(el)) continue;
    let hasDetectedChild = false;
    for (const ch of el.querySelectorAll("input, select, textarea")) {
      if (detectedEls.has(ch)) {
        hasDetectedChild = true;
        break;
      }
    }
    if (hasDetectedChild) continue;
    const text = (el.textContent ?? "").trim();
    if (text.length === 0 || text.length > 200) continue;
    if (isHidden(el)) continue;
    const tag = el.tagName.toLowerCase();
    if (["button", "a", "h1", "h2", "h3", "h4", "h5", "h6", "label", "fieldset", "legend"].includes(tag)) continue;
    const id = `ov-cand-${i++}`;
    el.setAttribute(FIELD_ATTR, id);
    out.push({
      el,
      cand: {
        id,
        tag,
        text,
        section: findSection(el),
        reason: "labelled container, no input child"
      }
    });
    if (out.length >= 12) break;
  }
  return out;
}
function findLabel(el) {
  const labelledby = el.getAttribute("aria-labelledby");
  if (labelledby) {
    const parts = [];
    for (const ref of labelledby.split(/\s+/).filter(Boolean)) {
      const ref_el = el.ownerDocument.getElementById(ref);
      if (!ref_el) continue;
      const txt = directText(ref_el) || (ref_el.textContent ?? "").trim();
      if (txt) parts.push(txt);
    }
    if (parts.length) return cleanLabel(parts.join(" "));
  }
  const id = el.getAttribute("id");
  if (id) {
    const l = el.ownerDocument.querySelector(`label[for="${CSS.escape(id)}"]`);
    if (l) {
      const txt = directText(l) || (l.textContent ?? "").trim();
      if (txt) return cleanLabel(txt);
    }
  }
  const parent = el.closest("label");
  if (parent) {
    const txt = directText(parent) || (parent.textContent ?? "").trim();
    if (txt) return cleanLabel(txt);
  }
  const fallback = (el.getAttribute("aria-label") ?? el.getAttribute("title") ?? el.placeholder ?? el.getAttribute("aria-placeholder") ?? "").trim();
  return cleanLabel(fallback);
}
function cleanLabel(s) {
  const collapsed = s.replace(/\s+/g, " ").replace(/^\*+\s*/g, "").replace(/\s*\(\s*required\s*\)\s*/gi, " ").replace(/\s*\(\s*optional\s*\)\s*/gi, " ").replace(/\s+\(req…[^)]*\)\s*/gi, " ").trim();
  if (collapsed.length <= 140) return collapsed;
  return collapsed.slice(0, 137).trimEnd() + "…";
}
function directText(el) {
  let out = "";
  for (const n of Array.from(el.childNodes)) {
    if (n.nodeType === Node.TEXT_NODE) out += n.textContent ?? "";
  }
  return out.trim();
}
function findSection(el) {
  const fs = el.closest("fieldset");
  if (fs) {
    const legend = fs.querySelector(":scope > legend");
    const txt = legend?.textContent?.trim();
    if (txt) return cleanLabel(txt);
  }
  let parent = el.parentElement;
  while (parent) {
    const role = parent.getAttribute("role");
    if (role === "group" || role === "region") {
      const aria = parent.getAttribute("aria-label")?.trim();
      if (aria) return cleanLabel(aria);
      const labelledby = parent.getAttribute("aria-labelledby");
      if (labelledby) {
        const ref = parent.ownerDocument.getElementById(labelledby.split(/\s+/)[0]);
        const txt = ref?.textContent?.trim();
        if (txt) return cleanLabel(txt);
      }
    }
    parent = parent.parentElement;
  }
  const form = el.closest("form") ?? el.ownerDocument.body;
  const headings = Array.from(form.querySelectorAll("h1, h2, h3, h4, h5, h6"));
  let preceding;
  for (const h of headings) {
    if (h.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) preceding = h;
    else break;
  }
  return cleanLabel(preceding?.textContent ?? "");
}
function valueIsCompatible(el, value) {
  if (!(el instanceof HTMLInputElement)) return true;
  const type = el.type;
  switch (type) {
    case "date":
      return /^\d{4}-\d{2}-\d{2}$/.test(value);
    case "time":
      return /^\d{2}:\d{2}(:\d{2})?$/.test(value);
    case "datetime-local":
      return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value);
    case "month":
      return /^\d{4}-\d{2}$/.test(value);
    case "week":
      return /^\d{4}-W\d{2}$/.test(value);
    case "number":
    case "range":
      return /^-?\d+(\.\d+)?$/.test(value);
    case "email":
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    case "url":
      return /^https?:\/\/\S+/.test(value);
    case "color":
      return /^#[0-9a-f]{6}$/i.test(value);
    default:
      return true;
  }
}
const COUNTRY_ALIASES = {
  "united states": ["united states", "united states of america", "usa", "us", "u.s.", "u.s.a.", "america"],
  "india": ["india", "ind", "in", "bharat"],
  "canada": ["canada", "can", "ca"],
  "united kingdom": ["united kingdom", "uk", "u.k.", "great britain", "britain", "england", "gb", "gbr"]
};
function normalizeChoice(s) {
  return s.toLowerCase().replace(/&amp;/g, "and").replace(/[^a-z0-9]+/g, " ").trim();
}
function choiceCandidates(value) {
  const norm = normalizeChoice(value);
  const out = /* @__PURE__ */ new Set([norm]);
  if (COUNTRY_ALIASES[norm]) {
    for (const alias of COUNTRY_ALIASES[norm]) out.add(normalizeChoice(alias));
  }
  for (const aliases of Object.values(COUNTRY_ALIASES)) {
    if (aliases.some((a) => normalizeChoice(a) === norm)) {
      for (const alias of aliases) out.add(normalizeChoice(alias));
    }
  }
  if (/\bmale\b/.test(norm)) out.add("m");
  if (/\bfemale\b/.test(norm)) out.add("f");
  return [...out];
}
function setSelectValue(el, value) {
  const wanted = choiceCandidates(value);
  const options = Array.from(el.options);
  const match = options.find((o) => {
    const ov = normalizeChoice(o.value);
    const ot = normalizeChoice(o.textContent ?? "");
    return wanted.includes(ov) || wanted.includes(ot);
  }) ?? options.find((o) => {
    const ov = normalizeChoice(o.value);
    const ot = normalizeChoice(o.textContent ?? "");
    return wanted.some((w) => w.length > 2 && (ov.includes(w) || ot.includes(w)) || ov.length > 2 && w.includes(ov) || ot.length > 2 && w.includes(ot));
  });
  if (!match) return false;
  el.value = match.value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function visible(el) {
  if (!(el instanceof HTMLElement)) return false;
  return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
}
function dispatchKey(el, key) {
  for (const type of ["keydown", "keyup"]) {
    el.dispatchEvent(new KeyboardEvent(type, { key, bubbles: true, cancelable: true }));
  }
}
function clickMatchingOption(doc, value) {
  const wanted = choiceCandidates(value);
  const candidates = Array.from(doc.querySelectorAll(
    "[role='option'], [role='menuitem'], [role='listitem'], li, [data-value], [data-option-value]"
  )).filter(visible);
  const match = candidates.find((el) => {
    const text = normalizeChoice(el.textContent ?? "");
    const dataValue = normalizeChoice(el.getAttribute("data-value") ?? el.getAttribute("data-option-value") ?? "");
    if (!text && !dataValue) return false;
    return wanted.some(
      (w) => w === text || w === dataValue || w.length > 2 && (text.includes(w) || dataValue.includes(w)) || text.length > 2 && w.includes(text) || dataValue.length > 2 && w.includes(dataValue)
    );
  });
  if (!match) return false;
  match.click();
  match.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
  match.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
  match.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  return true;
}
function setNativeValue(el, value) {
  if (!valueIsCompatible(el, value)) return false;
  if (el instanceof HTMLSelectElement) return setSelectValue(el, value);
  if (!(el instanceof HTMLInputElement) && !(el instanceof HTMLTextAreaElement) && !(el instanceof HTMLSelectElement)) {
    el.textContent = value;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  const proto = Object.getPrototypeOf(el);
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (setter) setter.call(el, value);
  else el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}
async function setFillValue(el, value) {
  if (el.getAttribute("role") === "combobox") {
    el.focus();
    el.click();
    const wrote = setNativeValue(el, value);
    if (!wrote) return false;
    await sleep(180);
    const clicked = clickMatchingOption(el.ownerDocument, value);
    if (clicked) return true;
    dispatchKey(el, "ArrowDown");
    dispatchKey(el, "Enter");
    return true;
  }
  return setNativeValue(el, value);
}
function optionsFor(el) {
  if (el instanceof HTMLSelectElement) {
    return Array.from(el.options).map((o) => o.textContent?.trim() ?? "").filter((t) => t.length > 0);
  }
  if (el instanceof HTMLInputElement && el.type === "radio") {
    const name = el.name;
    if (!name) return void 0;
    const group = el.ownerDocument.querySelectorAll(`input[type='radio'][name="${CSS.escape(name)}"]`);
    return Array.from(group).map((r) => findLabel(r)).filter((t) => t.length > 0);
  }
  return void 0;
}
function maxLengthOf(el) {
  const ml = el.getAttribute("maxlength");
  if (ml) {
    const n = parseInt(ml, 10);
    if (n > 0) return n;
  }
  return void 0;
}
function formFingerprint() {
  const u = new URL(location.href);
  const segments = u.pathname.split("/").filter(Boolean).slice(0, 2).join("/");
  return `${u.origin}/${segments}`;
}
async function readIntent() {
  const fp = formFingerprint();
  return new Promise((resolve) => {
    try {
      chrome.storage?.local?.get(`intent:${fp}`, (v) => {
        const obj = v;
        resolve(obj[`intent:${fp}`]?.text);
      });
    } catch {
      resolve(void 0);
    }
  });
}
async function writeIntent(text) {
  const fp = formFingerprint();
  return new Promise((resolve) => {
    try {
      chrome.storage?.local?.set({ [`intent:${fp}`]: { text, at: Date.now() } }, () => resolve());
    } catch {
      resolve();
    }
  });
}
async function readSession() {
  const fp = formFingerprint();
  return new Promise((resolve) => {
    try {
      chrome.storage?.local?.get(`session:${fp}`, (v) => {
        resolve(v[`session:${fp}`]);
      });
    } catch {
      resolve(void 0);
    }
  });
}
async function appendSessionFills(newFills) {
  if (newFills.length === 0) return;
  const fp = formFingerprint();
  const existing = await readSession() ?? { startedAt: Date.now(), fills: [] };
  const next = {
    startedAt: existing.startedAt,
    fills: [...existing.fills, ...newFills]
  };
  return new Promise((resolve) => {
    try {
      chrome.storage?.local?.set({ [`session:${fp}`]: next }, () => resolve());
    } catch {
      resolve();
    }
  });
}
async function endSession() {
  const fp = formFingerprint();
  return new Promise((resolve) => {
    try {
      chrome.storage?.local?.remove([`session:${fp}`, `intent:${fp}`], () => resolve());
    } catch {
      resolve();
    }
  });
}
function promptForIntent() {
  return new Promise((resolve) => {
    const id = "octovault-intent";
    document.getElementById(id)?.remove();
    const wrap = document.createElement("div");
    wrap.id = id;
    Object.assign(wrap.style, {
      position: "fixed",
      right: "20px",
      bottom: "70px",
      zIndex: "2147483647",
      width: "340px",
      background: "#0a0a0a",
      color: "#f5f5f5",
      border: "1px solid rgba(245,245,245,0.18)",
      borderRadius: "10px",
      fontFamily: "Inter, system-ui, sans-serif",
      boxShadow: "0 10px 36px rgba(0,0,0,0.5)",
      padding: "12px",
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    });
    const head = document.createElement("div");
    head.textContent = "What are you filling this out for?";
    Object.assign(head.style, { fontSize: "12px", fontWeight: "600" });
    const sub = document.createElement("div");
    sub.textContent = "A sentence or two — dates, purpose, who's involved. OctoVault uses this to draft text fields.";
    Object.assign(sub.style, { fontSize: "10.5px", opacity: "0.7", lineHeight: "1.4" });
    const ta = document.createElement("textarea");
    ta.rows = 3;
    Object.assign(ta.style, {
      background: "#1a1a1a",
      color: "#f5f5f5",
      border: "1px solid rgba(245,245,245,0.18)",
      borderRadius: "6px",
      padding: "8px",
      fontSize: "12px",
      fontFamily: "inherit",
      resize: "vertical"
    });
    const actions = document.createElement("div");
    Object.assign(actions.style, { display: "flex", justifyContent: "flex-end", gap: "6px" });
    const skip = document.createElement("button");
    skip.textContent = "Skip";
    Object.assign(skip.style, {
      background: "transparent",
      color: "#f5f5f5",
      border: "1px solid rgba(245,245,245,0.25)",
      borderRadius: "6px",
      padding: "4px 10px",
      fontSize: "11px",
      cursor: "pointer"
    });
    const cont = document.createElement("button");
    cont.textContent = "Continue";
    Object.assign(cont.style, {
      background: "#f5f5f5",
      color: "#0a0a0a",
      border: "none",
      borderRadius: "6px",
      padding: "4px 12px",
      fontSize: "11px",
      fontWeight: "600",
      cursor: "pointer"
    });
    skip.addEventListener("click", () => {
      wrap.remove();
      resolve("");
    });
    cont.addEventListener("click", () => {
      const v = ta.value.trim();
      wrap.remove();
      resolve(v);
    });
    actions.appendChild(skip);
    actions.appendChild(cont);
    wrap.appendChild(head);
    wrap.appendChild(sub);
    wrap.appendChild(ta);
    wrap.appendChild(actions);
    document.documentElement.appendChild(wrap);
    ta.focus();
  });
}
async function runFill() {
  const detected = detectFields();
  const composites = detectDateComposites(detected);
  const compositePartEls = /* @__PURE__ */ new Set();
  for (const c of composites) {
    compositePartEls.add(c.parts.year);
    compositePartEls.add(c.parts.month);
    compositePartEls.add(c.parts.day);
  }
  const radioGroups = detectRadioGroups(detected);
  const radioPartEls = /* @__PURE__ */ new Set();
  for (const g of radioGroups) {
    for (const p of g.parts) radioPartEls.add(p);
    g.parts[0].setAttribute(FIELD_ATTR, g.syntheticId);
  }
  const checkboxGroups = detectCheckboxGroups(detected);
  const checkboxPartEls = /* @__PURE__ */ new Set();
  for (const g of checkboxGroups) {
    for (const p of g.parts) checkboxPartEls.add(p);
    g.parts[0].setAttribute(FIELD_ATTR, g.syntheticId);
  }
  const detectedSansParts = detected.filter(
    (d) => !compositePartEls.has(d.el) && !radioPartEls.has(d.el) && !checkboxPartEls.has(d.el)
  );
  const detectedSet = new Set(detectedSansParts.map((d) => d.el));
  const candidates = detectSuspicious(detectedSet);
  if (detectedSansParts.length === 0 && composites.length === 0 && candidates.length === 0) {
    toast("No fillable fields detected on this view.");
    return;
  }
  const fieldOptions = {};
  const fieldMaxLengths = {};
  for (const d of detectedSansParts) {
    const opts = optionsFor(d.el);
    if (opts && opts.length) fieldOptions[d.field.id] = opts;
    const ml = maxLengthOf(d.el);
    if (ml) fieldMaxLengths[d.field.id] = ml;
  }
  for (const g of radioGroups) {
    fieldOptions[g.syntheticId] = g.options;
  }
  for (const g of checkboxGroups) {
    fieldOptions[g.syntheticId] = g.options;
  }
  const wouldGenerate = detectedSansParts.some((d) => isLikelyOpenField(d.field, !!fieldOptions[d.field.id]?.length)) || radioGroups.some((g) => isLikelyOpenField(g.field, true)) || checkboxGroups.some((g) => isLikelyOpenField(g.field, true));
  let intent = "";
  if (wouldGenerate) {
    const stored = await readIntent();
    if (stored != null) intent = stored;
    else {
      const got = await promptForIntent();
      if (got === void 0) return;
      intent = got;
      if (intent) await writeIntent(intent);
    }
  }
  toast("Matching fields…");
  const compositeById = new Map(composites.map((c) => [c.syntheticId, c]));
  let resp;
  try {
    resp = await chrome.runtime.sendMessage({
      type: "form.match",
      fields: [
        ...detectedSansParts.map((d) => d.field),
        ...composites.map((c) => c.field),
        ...radioGroups.map((g) => g.field),
        ...checkboxGroups.map((g) => g.field)
      ],
      candidates: candidates.map((c) => c.cand),
      intent,
      fieldOptions,
      fieldMaxLengths
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("Extension context invalidated")) {
      toast("OctoVault was reloaded. Refresh this page (⌘R) to re-link.");
    } else {
      toast(`Error: ${msg}`);
    }
    return;
  }
  if (!resp?.ok) {
    toast(`Error: ${resp?.error ?? "unknown"}`);
    return;
  }
  const data = resp.data;
  const { matches, vault, entities, source = "extension", fields: enrichedFields, enrichment, drafts = [] } = data;
  const entityName = (eid) => entities.find((e) => e.id === eid)?.name ?? (eid === "self" ? "Self" : eid);
  const totalProfileKeys = Object.values(vault).reduce((n, p) => n + Object.keys(p).length, 0);
  const clientKnownIds = /* @__PURE__ */ new Set([
    ...detectedSansParts.map((d) => d.field.id),
    ...composites.map((c) => c.syntheticId),
    ...radioGroups.map((g) => g.syntheticId),
    ...checkboxGroups.map((g) => g.syntheticId)
  ]);
  const promotedIds = new Set(
    enrichedFields.filter((f) => !clientKnownIds.has(f.id)).map((f) => f.id)
  );
  function elFor(fieldId) {
    return document.querySelector(`[${FIELD_ATTR}="${fieldId}"]`);
  }
  const rows = [];
  for (const m of matches) {
    const field = enrichedFields.find((f) => f.id === m.fieldId);
    const composite = compositeById.get(m.fieldId);
    const label = field?.label || field?.name || m.fieldId;
    const promoted = promotedIds.has(m.fieldId);
    const record = field && m.profileKey ? vault[m.entityId]?.[m.profileKey] : void 0;
    const canonicalId = record?.canonicalId;
    const value = record?.candidates.find((c) => c.id === canonicalId)?.value;
    if (!field || !m.profileKey) {
      rows.push({
        fieldId: m.fieldId,
        label,
        status: "skipped",
        reason: promoted ? "LLM-promoted; no profile key matched" : "no profile key matched",
        entityName: entityName(m.entityId)
      });
      continue;
    }
    if (!value) {
      rows.push({
        fieldId: m.fieldId,
        label,
        status: "skipped",
        reason: `matched ${m.entityId}.${m.profileKey} but no canonical value`,
        entityName: entityName(m.entityId),
        profileKey: m.profileKey
      });
      continue;
    }
    if (composite) {
      const ok = fillDateComposite(composite.parts, value);
      if (!ok) {
        rows.push({
          fieldId: m.fieldId,
          label,
          status: "skipped",
          reason: `composite date "${value}" couldn't be decomposed (one or more parts missing the option)`,
          entityName: entityName(m.entityId),
          profileKey: m.profileKey,
          value
        });
        continue;
      }
      for (const p of [composite.parts.year, composite.parts.month, composite.parts.day]) {
        p.style.outline = m.conflicted ? "2px dashed currentColor" : "2px solid currentColor";
        p.style.outlineOffset = "1px";
        setTimeout(() => {
          p.style.outline = "";
          p.style.outlineOffset = "";
        }, 2500);
      }
      rows.push({
        fieldId: m.fieldId,
        label,
        status: "filled",
        reason: `${entityName(m.entityId)}.${m.profileKey} = ${value} → Y/M/D parts`,
        entityName: entityName(m.entityId),
        profileKey: m.profileKey,
        conflicted: m.conflicted,
        value
      });
      continue;
    }
    const el = elFor(m.fieldId);
    if (!el) {
      rows.push({
        fieldId: m.fieldId,
        label,
        status: "skipped",
        reason: "no DOM element found for this match",
        entityName: entityName(m.entityId),
        profileKey: m.profileKey
      });
      continue;
    }
    const wrote = await setFillValue(el, value);
    if (!wrote) {
      rows.push({
        fieldId: m.fieldId,
        label,
        status: "skipped",
        reason: `"${value}" doesn't fit ${field.type} input`,
        entityName: entityName(m.entityId),
        profileKey: m.profileKey,
        value
      });
      continue;
    }
    el.style.outline = m.conflicted ? "2px dashed currentColor" : "2px solid currentColor";
    el.style.outlineOffset = "1px";
    setTimeout(() => {
      el.style.outline = "";
      el.style.outlineOffset = "";
    }, 2500);
    rows.push({
      fieldId: m.fieldId,
      label,
      status: "filled",
      reason: `${entityName(m.entityId)}.${m.profileKey} = ${value}${promoted ? " (LLM-promoted)" : ""}`,
      entityName: entityName(m.entityId),
      profileKey: m.profileKey,
      conflicted: m.conflicted,
      value,
      hidden: field.hidden
    });
  }
  const parsedDates = parseIntentDates(intent);
  if (parsedDates.start || parsedDates.end) {
    const filledIds = new Set(rows.filter((r) => r.status === "filled").map((r) => r.fieldId));
    for (const c of composites) {
      if (filledIds.has(c.syntheticId)) continue;
      const iso = pickIntentDateForComposite(c.field.label, parsedDates);
      if (!iso) continue;
      const ok = fillDateComposite(c.parts, iso);
      const existingIdx = rows.findIndex((r) => r.fieldId === c.syntheticId);
      const filledRow = ok ? {
        fieldId: c.syntheticId,
        label: c.field.label,
        status: "filled",
        reason: `from intent: ${iso}`,
        value: iso,
        entityName: "intent"
      } : {
        fieldId: c.syntheticId,
        label: c.field.label,
        status: "skipped",
        reason: `intent gave ${iso} but selects didn't have a matching option`,
        entityName: "intent"
      };
      if (existingIdx >= 0) rows[existingIdx] = filledRow;
      else rows.push(filledRow);
      if (ok) {
        for (const p of [c.parts.year, c.parts.month, c.parts.day]) {
          p.style.outline = "2px solid currentColor";
          p.style.outlineOffset = "1px";
          setTimeout(() => {
            p.style.outline = "";
            p.style.outlineOffset = "";
          }, 2500);
        }
      }
    }
  }
  if (enrichment) {
    const ncorr = Object.keys(enrichment.corrections).length;
    const npromo = enrichment.promotions.length;
    if (ncorr || npromo) {
      console.log(`[OctoVault] LLM enrichment: ${ncorr} label correction${ncorr === 1 ? "" : "s"}, ${npromo} candidate promotion${npromo === 1 ? "" : "s"}`);
    }
  }
  console.log(`[OctoVault] drafts: ${drafts.length}`, drafts);
  console.table(rows.map((r) => ({ id: r.fieldId, label: r.label.slice(0, 40), status: r.status, reason: r.reason.slice(0, 80), entity: r.entityName, key: r.profileKey })));
  const filled = rows.filter((r) => r.status === "filled").length;
  const skipped = rows.filter((r) => r.status === "skipped").length;
  console.group("[OctoVault] form fill");
  console.log(`Source: ${source} · Entities: ${entities.length} · Total profile keys: ${totalProfileKeys}`);
  console.log("Detected:", detected.map((d) => d.field));
  console.log("Rows:", rows);
  console.groupEnd();
  if (totalProfileKeys === 0 && drafts.length === 0) {
    toast(`Vault (${source}) is empty. Open OctoVault and import a doc.`);
    return;
  }
  const draftItems = [];
  for (const d of drafts) {
    const field = enrichedFields.find((f) => f.id === d.fieldId);
    if (!field) continue;
    const el = elFor(d.fieldId);
    draftItems.push({
      fieldId: d.fieldId,
      label: field.label || d.fieldId,
      draft: d.draft,
      reason: d.reason,
      confidence: d.confidence,
      el: el ?? void 0,
      fieldType: field.type,
      options: fieldOptions[d.fieldId]
    });
  }
  const filledRows = rows.filter((r) => r.status === "filled");
  if (filledRows.length > 0) {
    void appendSessionFills(filledRows.map((r) => ({
      url: location.href,
      label: r.label,
      value: r.value ?? "",
      at: Date.now(),
      entityId: r.entityName ?? "self",
      profileKey: r.profileKey ?? ""
    })));
  }
  const session = await readSession();
  showHud({ rows, source, filled, skipped, drafts: draftItems, session });
  watchForRejections(rows);
}
const OCTO_MARK_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
  <polygon points="7,1.5 17,1.5 22.5,7 22.5,17 17,22.5 7,22.5 1.5,17 1.5,7"
           fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>
  <circle cx="12" cy="11" r="1.75" fill="currentColor"/>
  <path d="M11 12.5 L11 16.25 L13 16.25 L13 12.5 Z" fill="currentColor"/>
</svg>`;
function mountButton() {
  if (document.getElementById("octovault-launcher")) return;
  if (window.top !== window && detectFields().length === 0) return;
  const btn = document.createElement("button");
  btn.id = "octovault-launcher";
  btn.innerHTML = `${OCTO_MARK_SVG}<span id="octovault-launcher-label">Fill</span><span id="octovault-launcher-count" style="display:none;font-size:11px;font-weight:500;opacity:0.7"></span>`;
  Object.assign(btn.style, {
    position: "fixed",
    right: "20px",
    bottom: "20px",
    zIndex: "2147483647",
    background: "#0a0a0a",
    color: "#f5f5f5",
    border: "1px solid #f5f5f5",
    borderRadius: "999px",
    padding: "8px 14px",
    fontSize: "13px",
    fontWeight: "600",
    fontFamily: "Inter, system-ui, sans-serif",
    cursor: "pointer",
    boxShadow: "0 6px 24px rgba(0,0,0,0.35)",
    display: "inline-flex",
    alignItems: "center",
    gap: "8px"
  });
  btn.addEventListener("click", () => void runFill());
  document.documentElement.appendChild(btn);
}
let devBadgeEnabled = false;
function applyDevBadgeUi(count) {
  const countEl = document.getElementById("octovault-launcher-count");
  if (!countEl) return;
  if (devBadgeEnabled && count > 0) {
    countEl.textContent = `· ${count}`;
    countEl.style.display = "inline";
  } else {
    countEl.style.display = "none";
  }
}
function loadDevBadgeFlag() {
  try {
    chrome.storage?.local?.get("octovaultDevBadge", (v) => {
      devBadgeEnabled = !!v?.octovaultDevBadge;
      applyDevBadgeUi(lastFieldCount);
    });
    chrome.storage?.onChanged?.addListener?.((changes, area) => {
      if (area !== "local" || !changes.octovaultDevBadge) return;
      devBadgeEnabled = !!changes.octovaultDevBadge.newValue;
      applyDevBadgeUi(lastFieldCount);
    });
  } catch {
  }
}
function watchForRejections(rows) {
  const filled = rows.filter((r) => r.status === "filled");
  if (filled.length === 0) return;
  const watchers = [];
  for (const r of filled) {
    const el = document.querySelector(`[${FIELD_ATTR}="${r.fieldId}"]`);
    if (!el) continue;
    const mo = new MutationObserver(() => {
      const invalid = el.getAttribute("aria-invalid");
      if (invalid === "true") flagRejected(r.fieldId);
    });
    mo.observe(el, { attributes: true, attributeFilter: ["aria-invalid"] });
    watchers.push(mo);
  }
  setTimeout(() => {
    for (const w of watchers) w.disconnect();
  }, 8e3);
}
function flagRejected(fieldId) {
  const hud = document.getElementById("octovault-hud");
  if (!hud) return;
  const row = hud.querySelector(`[data-fid="${fieldId}"]`);
  if (!row) return;
  if (row.querySelector(".octovault-rejected")) return;
  const tag = document.createElement("span");
  tag.className = "octovault-rejected";
  tag.textContent = "rejected";
  Object.assign(tag.style, {
    background: "#7f1d1d",
    color: "#fecaca",
    fontSize: "9.5px",
    padding: "1px 5px",
    borderRadius: "6px",
    marginLeft: "6px"
  });
  row.querySelector("div")?.appendChild(tag);
}
function showHud(report) {
  const id = "octovault-hud";
  document.getElementById(id)?.remove();
  const wrap = document.createElement("div");
  wrap.id = id;
  Object.assign(wrap.style, {
    position: "fixed",
    right: "20px",
    bottom: "70px",
    zIndex: "2147483647",
    width: "340px",
    maxHeight: "60vh",
    background: "#0a0a0a",
    color: "#f5f5f5",
    border: "1px solid rgba(245,245,245,0.18)",
    borderRadius: "10px",
    fontFamily: "Inter, system-ui, sans-serif",
    boxShadow: "0 10px 36px rgba(0,0,0,0.5)",
    display: "flex",
    flexDirection: "column",
    overflow: "hidden"
  });
  const header = document.createElement("div");
  Object.assign(header.style, {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "10px 12px",
    borderBottom: "1px solid rgba(245,245,245,0.12)",
    fontSize: "12px",
    fontWeight: "600"
  });
  const session = report.session;
  const sessionPageCount = session ? new Set(session.fills.map((f) => f.url)).size : 0;
  const sessionTotal = session?.fills.length ?? 0;
  header.innerHTML = `<span>Filled ${report.filled} · Skipped ${report.skipped} <span style="opacity:0.6;font-weight:500">· ${report.source}</span>${sessionTotal > 0 ? `<div style="font-size:10px;opacity:0.65;font-weight:500;margin-top:2px">Session: ${sessionTotal} across ${sessionPageCount} page${sessionPageCount === 1 ? "" : "s"}</div>` : ""}</span>`;
  const headerActions = document.createElement("div");
  Object.assign(headerActions.style, { display: "flex", alignItems: "center", gap: "4px" });
  if (sessionTotal > 0) {
    const endBtn = document.createElement("button");
    endBtn.textContent = "End session";
    Object.assign(endBtn.style, {
      background: "transparent",
      color: "#f5f5f5",
      border: "1px solid rgba(245,245,245,0.2)",
      borderRadius: "6px",
      padding: "2px 8px",
      fontSize: "10px",
      cursor: "pointer"
    });
    endBtn.addEventListener("click", async () => {
      await endSession();
      wrap.remove();
      toast("Session ended.");
    });
    headerActions.appendChild(endBtn);
  }
  const closeBtn = document.createElement("button");
  closeBtn.textContent = "×";
  Object.assign(closeBtn.style, {
    background: "transparent",
    color: "#f5f5f5",
    border: "none",
    fontSize: "18px",
    lineHeight: "1",
    cursor: "pointer",
    padding: "0 4px"
  });
  closeBtn.addEventListener("click", () => wrap.remove());
  headerActions.appendChild(closeBtn);
  header.appendChild(headerActions);
  wrap.appendChild(header);
  const scroller = document.createElement("div");
  Object.assign(scroller.style, {
    overflowY: "auto",
    flex: "1 1 auto",
    minHeight: "0"
  });
  wrap.appendChild(scroller);
  const body = document.createElement("div");
  Object.assign(body.style, {
    padding: "8px 4px",
    fontSize: "11.5px",
    lineHeight: "1.4"
  });
  const byEntity = /* @__PURE__ */ new Map();
  for (const r of report.rows) {
    const k = r.entityName ?? "(?)";
    const arr = byEntity.get(k) ?? [];
    arr.push(r);
    byEntity.set(k, arr);
  }
  for (const [entityName, rows] of byEntity) {
    const section = document.createElement("div");
    Object.assign(section.style, { padding: "4px 10px 6px" });
    const head = document.createElement("div");
    head.textContent = entityName;
    Object.assign(head.style, {
      fontSize: "10px",
      textTransform: "uppercase",
      letterSpacing: "0.15em",
      opacity: "0.55",
      margin: "4px 0 4px"
    });
    section.appendChild(head);
    rows.sort((a, b) => a.status === b.status ? 0 : a.status === "filled" ? -1 : 1);
    for (const r of rows) {
      const row = document.createElement("div");
      row.setAttribute("data-fid", r.fieldId);
      const dot = r.status === "filled" ? "●" : "○";
      const dotColor = r.status === "filled" ? r.conflicted ? "#facc15" : "#34d399" : "#a3a3a3";
      Object.assign(row.style, {
        display: "flex",
        alignItems: "flex-start",
        gap: "6px",
        padding: "3px 4px"
      });
      const dotEl = document.createElement("span");
      dotEl.textContent = dot;
      Object.assign(dotEl.style, { color: dotColor, flex: "0 0 auto", marginTop: "1px" });
      row.appendChild(dotEl);
      const txt = document.createElement("div");
      txt.style.cssText = "flex:1;min-width:0;line-height:1.35;";
      txt.innerHTML = `<div style="opacity:0.95;display:block !important;line-height:1.35 !important;overflow-wrap:anywhere;">${escapeHtml(r.label)}${r.hidden ? ' <span style="opacity:0.5">(hidden)</span>' : ""}</div><div style="opacity:0.55;font-size:10.5px;display:block !important;line-height:1.35 !important;overflow-wrap:anywhere;">${escapeHtml(r.reason)}</div>`;
      row.appendChild(txt);
      section.appendChild(row);
    }
    body.appendChild(section);
  }
  scroller.appendChild(body);
  const drafts = report.drafts ?? [];
  if (drafts.length > 0) {
    const section = document.createElement("div");
    Object.assign(section.style, {
      borderTop: "1px solid rgba(245,245,245,0.12)",
      padding: "8px 10px 10px"
    });
    const headRow = document.createElement("div");
    Object.assign(headRow.style, { display: "flex", alignItems: "center", justifyContent: "space-between", margin: "0 0 6px" });
    const head = document.createElement("div");
    head.textContent = `Drafts (${drafts.length}) — review before filling`;
    Object.assign(head.style, {
      fontSize: "10px",
      textTransform: "uppercase",
      letterSpacing: "0.15em",
      opacity: "0.6"
    });
    const fillAllBtn = document.createElement("button");
    fillAllBtn.textContent = "Fill all";
    Object.assign(fillAllBtn.style, {
      background: "#f5f5f5",
      color: "#0a0a0a",
      border: "none",
      borderRadius: "6px",
      padding: "2px 10px",
      fontSize: "10px",
      fontWeight: "600",
      cursor: "pointer"
    });
    fillAllBtn.addEventListener("click", () => {
      const fills = section.querySelectorAll("button[data-fill='1']:not([disabled])");
      for (const b of fills) b.click();
    });
    headRow.appendChild(head);
    headRow.appendChild(fillAllBtn);
    section.appendChild(headRow);
    for (const d of drafts) {
      const row = document.createElement("div");
      Object.assign(row.style, {
        marginBottom: "8px",
        padding: "6px 8px",
        background: "rgba(245,245,245,0.05)",
        borderRadius: "6px"
      });
      const labelEl = document.createElement("div");
      labelEl.innerHTML = `<span style="opacity:0.95">${escapeHtml(d.label)}</span> <span style="opacity:0.45;font-size:10px">· ${d.confidence}</span>`;
      Object.assign(labelEl.style, { fontSize: "11.5px", marginBottom: "4px" });
      row.appendChild(labelEl);
      if (d.options?.length) {
        const list = document.createElement("div");
        Object.assign(list.style, { display: "flex", flexWrap: "wrap", gap: "4px" });
        for (const opt of d.options) {
          const btn = document.createElement("button");
          btn.textContent = opt;
          const selected = opt.trim().toLowerCase() === d.draft.trim().toLowerCase();
          Object.assign(btn.style, {
            background: selected ? "#f5f5f5" : "transparent",
            color: selected ? "#0a0a0a" : "#f5f5f5",
            border: "1px solid rgba(245,245,245,0.25)",
            borderRadius: "999px",
            padding: "2px 8px",
            fontSize: "10.5px",
            cursor: "pointer"
          });
          btn.addEventListener("click", () => {
            if (!d.el) return;
            if (d.el instanceof HTMLInputElement && d.el.type === "radio") {
              const container = d.el.closest("[role='radiogroup'], fieldset, [role='group']");
              const group = d.el.name ? d.el.ownerDocument.querySelectorAll(`input[type='radio'][name="${CSS.escape(d.el.name)}"]`) : container?.querySelectorAll("input[type='radio']") ?? [d.el];
              for (const r of group) {
                const wanted = normalizeChoice(opt);
                const rLabel = normalizeChoice(findLabel(r));
                const associatedLabel = (r.id ? r.ownerDocument.querySelector(`label[for="${CSS.escape(r.id)}"]`) : null) ?? r.closest("label");
                const optionWrapper = r.closest("[role='radio'], label, [class*='option'], [class*='Option']") ?? r.parentElement?.parentElement;
                const wrapperText = normalizeChoice(associatedLabel?.textContent ?? optionWrapper?.textContent ?? "");
                if (rLabel === wanted || wrapperText === wanted) {
                  r.checked = true;
                  optionWrapper?.click();
                  if (associatedLabel) associatedLabel.click();
                  r.click();
                  for (const evt of ["pointerdown", "pointerup", "mousedown", "mouseup", "click"]) {
                    optionWrapper?.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true }));
                    r.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true }));
                  }
                  r.dispatchEvent(new Event("change", { bubbles: true }));
                  r.dispatchEvent(new Event("input", { bubbles: true }));
                  btn.style.background = "#34d399";
                  btn.style.color = "#0a0a0a";
                  return;
                }
              }
            } else if (d.el instanceof HTMLInputElement && d.el.type === "checkbox") {
              const container = d.el.closest("fieldset, [role='group'], [aria-labelledby]");
              const group = d.el.name ? d.el.ownerDocument.querySelectorAll(`input[type='checkbox'][name="${CSS.escape(d.el.name)}"]`) : container?.querySelectorAll("input[type='checkbox']") ?? [d.el];
              const wanted = normalizeChoice(opt);
              for (const c of group) {
                const cLabel = normalizeChoice(findLabel(c));
                const associatedLabel = (c.id ? c.ownerDocument.querySelector(`label[for="${CSS.escape(c.id)}"]`) : null) ?? c.closest("label");
                const optionWrapper = c.closest("[role='checkbox'], label, [class*='option'], [class*='Option']") ?? c.parentElement?.parentElement;
                const wrapperText = normalizeChoice(associatedLabel?.textContent ?? optionWrapper?.textContent ?? "");
                if (cLabel === wanted || wrapperText === wanted) {
                  if (!c.checked) {
                    optionWrapper?.click();
                    if (associatedLabel) associatedLabel.click();
                    c.click();
                    for (const evt of ["pointerdown", "pointerup", "mousedown", "mouseup", "click"]) {
                      optionWrapper?.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true }));
                      c.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true }));
                    }
                    c.checked = true;
                    c.dispatchEvent(new Event("change", { bubbles: true }));
                    c.dispatchEvent(new Event("input", { bubbles: true }));
                  }
                  btn.style.background = "#34d399";
                  btn.style.color = "#0a0a0a";
                  return;
                }
              }
            } else if (d.el instanceof HTMLSelectElement) {
              const match = Array.from(d.el.options).find((o) => o.textContent?.trim().toLowerCase() === opt.trim().toLowerCase() || o.value === opt);
              if (match) {
                d.el.value = match.value;
                d.el.dispatchEvent(new Event("input", { bubbles: true }));
                d.el.dispatchEvent(new Event("change", { bubbles: true }));
                btn.style.background = "#34d399";
                btn.style.color = "#0a0a0a";
              }
            }
          });
          list.appendChild(btn);
        }
        row.appendChild(list);
      } else {
        const ta = document.createElement("textarea");
        ta.value = d.draft;
        ta.rows = 3;
        Object.assign(ta.style, {
          width: "100%",
          boxSizing: "border-box",
          background: "#1a1a1a",
          color: "#f5f5f5",
          border: "1px solid rgba(245,245,245,0.18)",
          borderRadius: "6px",
          padding: "6px 8px",
          fontSize: "11.5px",
          fontFamily: "inherit",
          resize: "vertical"
        });
        row.appendChild(ta);
        const actions = document.createElement("div");
        Object.assign(actions.style, { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "4px" });
        const reasonEl = document.createElement("span");
        reasonEl.textContent = d.reason;
        Object.assign(reasonEl.style, { fontSize: "10px", opacity: "0.55" });
        const fillBtn = document.createElement("button");
        fillBtn.textContent = "Fill";
        fillBtn.dataset.fill = "1";
        Object.assign(fillBtn.style, {
          background: "#f5f5f5",
          color: "#0a0a0a",
          border: "none",
          borderRadius: "6px",
          padding: "3px 12px",
          fontSize: "10.5px",
          fontWeight: "600",
          cursor: "pointer"
        });
        fillBtn.addEventListener("click", async () => {
          if (!d.el) return;
          const ok = await setFillValue(d.el, ta.value);
          if (ok) {
            fillBtn.textContent = "Filled";
            fillBtn.style.background = "#34d399";
            fillBtn.disabled = true;
          }
        });
        actions.appendChild(reasonEl);
        actions.appendChild(fillBtn);
        row.appendChild(actions);
      }
      section.appendChild(row);
    }
    scroller.appendChild(section);
  }
  document.documentElement.appendChild(wrap);
}
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
}
function toast(text) {
  const id = "octovault-toast";
  document.getElementById(id)?.remove();
  const t = document.createElement("div");
  t.id = id;
  t.textContent = text;
  Object.assign(t.style, {
    position: "fixed",
    right: "20px",
    bottom: "70px",
    zIndex: "2147483647",
    background: "#0a0a0a",
    color: "#f5f5f5",
    border: "1px solid rgba(245,245,245,0.2)",
    borderRadius: "8px",
    padding: "10px 14px",
    fontSize: "12px",
    fontFamily: "Inter, system-ui, sans-serif",
    maxWidth: "320px",
    boxShadow: "0 6px 24px rgba(0,0,0,0.35)"
  });
  document.documentElement.appendChild(t);
  setTimeout(() => t.remove(), 4500);
}
let lastFieldCount = -1;
function refreshDetection(reason) {
  const next = detectFields().length;
  if (window.top !== window && next === 0) {
    document.getElementById("octovault-launcher")?.remove();
  } else {
    mountButton();
  }
  if (next === lastFieldCount) return;
  lastFieldCount = next;
  applyDevBadgeUi(next);
  console.debug(`[OctoVault] detection refreshed (${reason}): ${next} fields`);
}
function installSpaHooks() {
  const w = window;
  if (w.__octovaultSpaHooksInstalled) return;
  w.__octovaultSpaHooksInstalled = true;
  const fire = () => window.dispatchEvent(new Event("locationchange"));
  const wrap = (name) => {
    const orig = history[name];
    history[name] = function patched(...args) {
      const r = orig.apply(this, args);
      fire();
      return r;
    };
  };
  wrap("pushState");
  wrap("replaceState");
  window.addEventListener("popstate", fire);
  window.addEventListener("locationchange", () => refreshDetection("spa"));
}
function installMutationObserver() {
  let timer = null;
  const schedule = () => {
    if (timer != null) return;
    timer = window.setTimeout(() => {
      timer = null;
      refreshDetection("mutation");
    }, 150);
  };
  const mo = new MutationObserver(schedule);
  mo.observe(document.documentElement, { childList: true, subtree: true });
}
mountButton();
loadDevBadgeFlag();
refreshDetection("init");
installSpaHooks();
installMutationObserver();
//# sourceMappingURL=index.ts-D_pyqD9o.js.map
