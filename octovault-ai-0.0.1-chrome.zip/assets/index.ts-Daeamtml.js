import { P as PROFILE_FIELDS, g as generateJson, a as generate, i as isReachable } from './vault-crypto-BP82NYQF.js';
import { i as isLikelyOpenField, g as generateFieldDrafts } from './generate-91Ccbizt.js';
import { b as bridgeReachable, f as fetchProfileFromBridge, i as indexedDbAdapter } from './bridge-Cc9R8awV.js';

const SECTION_ROUTES = [
  { pattern: /\b(spouse|wife|husband|partner)\b/i, relationship: "spouse" },
  { pattern: /\b(father|mother|parent|guardian)s?\b/i, relationship: "parent" },
  { pattern: /\b(child|son|daughter|kid|dependent)s?\b/i, relationship: "child" },
  { pattern: /\bsibling|brother|sister\b/i, relationship: "sibling" }
];
function routeSectionToEntity(section, entities) {
  if (!section) return "self";
  const trimmed = section.trim();
  if (!trimmed) return "self";
  for (const route of SECTION_ROUTES) {
    if (!route.pattern.test(trimmed)) continue;
    const candidates = entities.filter((e) => e.relationship === route.relationship);
    if (candidates.length === 0) return "self";
    const named = candidates.find((e) => e.name && trimmed.toLowerCase().includes(e.name.toLowerCase()));
    return (named ?? candidates[0]).id;
  }
  return "self";
}
const AUTOCOMPLETE_MAP = {
  "given-name": "firstName",
  "additional-name": "middleName",
  "family-name": "lastName",
  "name": "fullName",
  "email": "email",
  "tel": "phone",
  "tel-national": "phone",
  "street-address": "addressLine1",
  "address-line1": "addressLine1",
  "address-line2": "addressLine2",
  "address-level1": "state",
  "address-level2": "city",
  "postal-code": "postalCode",
  "country": "country",
  "country-name": "country",
  "bday": "dateOfBirth",
  "sex": "gender",
  "organization": "employerName",
  "organization-title": "jobTitle"
};
const FIELD_TEXT_HINTS = {
  fullName: [/\b(full|legal|applicant|customer|employee|beneficiary)\s+name\b/i, /\bname\s+as\s+.*passport\b/i],
  firstName: [/\b(first|given|forename)\s+name\b/i, /\bgiven\b/i],
  middleName: [/\bmiddle\s+(name|initial)\b/i],
  lastName: [/\b(last|family|sur|surname)\s+name\b/i, /\bsurname\b/i],
  dateOfBirth: [/\b(date\s+of\s+birth|birth\s+date|dob|birthday)\b/i],
  placeOfBirth: [/\b(place|city|country)\s+of\s+birth\b/i, /\bbirth\s+(place|city|country)\b/i],
  gender: [/\b(gender|sex)\b/i],
  nationality: [/\b(nationality|citizenship)\b/i],
  email: [/\b(e-?mail|email\s+address)\b/i],
  phone: [/\b(phone|mobile|cell|telephone|contact\s+number)\b/i],
  linkedinProfile: [/\blinked\s*in\b/i, /\blinkedin\s+(profile|url)\b/i],
  personalWebsite: [/\b(personal\s+)?website\b/i, /\bportfolio\b/i],
  githubProfile: [/\bgithub\b/i],
  publicationsUrl: [/\bpublications?\b/i, /\bgoogle\s+scholar\b/i, /\bscholar\s+url\b/i],
  addressLine1: [/\b(address\s+line\s*1|street\s+address|address)\b/i],
  addressLine2: [/\b(address\s+line\s*2|apt|apartment|unit|suite)\b/i],
  city: [/\b(city|town)\b/i, /\blocation\s*\(\s*city\s*\)\b/i],
  state: [/\b(state|province|region)\b/i],
  postalCode: [/\b(zip|postal|postcode|pin\s*code)\b/i],
  country: [/\b(country|country\s+of\s+residence|residence\s+country)\b/i],
  passportNumber: [/\bpassport\s+(number|no\.?|#)\b/i],
  passportIssuer: [/\b(passport\s+)?(issuing|issuer)\s+country\b/i],
  passportIssueDate: [/\bpassport\s+(issue|issued)\s+date\b/i, /\bdate\s+of\s+issue\b/i],
  passportExpiryDate: [/\bpassport\s+(expir(y|ation)|expires?)\b/i, /\bdate\s+of\s+expiry\b/i],
  driversLicenseNumber: [/\b(driver'?s?\s+license|dl)\s+(number|no\.?|#)\b/i],
  nationalIdNumber: [/\bnational\s+id\s+(number|no\.?|#)\b/i],
  ssn: [/\b(ssn|social\s+security)\b/i],
  taxIdNumber: [/\b(tax\s+id|tin|itin)\b/i],
  employerName: [/\b(employer|company|organization)\b/i],
  jobTitle: [/\b(job\s+title|position|role|occupation)\b/i],
  employmentStartDate: [/\b(employment|job|work).*\b(start|from|begin)\b/i, /\bdate\s+hired\b/i],
  employmentEndDate: [/\b(employment|job|work).*\b(end|until|to|last\s+day)\b/i],
  annualSalary: [/\b(salary|annual\s+income|base\s+pay|compensation)\b/i],
  visaType: [/\b(visa|status).*\b(type|class|classification|category)\b/i],
  uciNumber: [/\buci\b/i, /\bunique\s+client\s+identifier\b/i, /\bclient\s+id(entifier)?\b/i],
  visaReceiptNumber: [/\b(receipt|case|petition)\s+(number|no\.?|#)\b/i],
  visaValidFrom: [/\b(visa|petition).*\b(valid\s+from|start)\b/i],
  visaValidUntil: [/\b(visa|petition|status).*\b(valid\s+until|expires?|expiry|end)\b/i],
  visaPetitioner: [/\b(petitioner|sponsor)\b/i],
  visaBeneficiary: [/\bbeneficiary\b/i],
  i94Number: [/\bi-?94.*\b(number|no\.?|#)\b/i],
  i94ExpiryDate: [/\bi-?94.*\b(expir(y|ation)|admit\s+until|authorized\s+stay)\b/i],
  greenCardNumber: [/\b(green\s+card|permanent\s+resident).*\b(number|no\.?|#)\b/i],
  greenCardCategory: [/\bgreen\s+card.*\b(category|class)\b/i],
  naturalizationDate: [/\b(naturalization|citizenship).*\bdate\b/i],
  spouseName: [/\b(spouse|wife|husband|partner).*\bname\b/i],
  spouseDateOfBirth: [/\b(spouse|wife|husband|partner).*\b(dob|birth)\b/i],
  marriageDate: [/\b(marriage|wedding).*\bdate\b/i],
  marriagePlace: [/\b(marriage|wedding).*\b(place|city|location)\b/i],
  marriageCertificateNumber: [/\bmarriage.*\b(certificate|license).*\b(number|no\.?|#)\b/i],
  fatherName: [/\b(father|dad|parent\s*1).*\bname\b/i, /\bfather\b/i],
  motherName: [/\b(mother|mom|parent\s*2|maiden).*\bname\b/i, /\bmother\b/i],
  emergencyContactName: [/\bemergency\s+contact.*\bname\b/i],
  emergencyContactPhone: [/\bemergency\s+contact.*\b(phone|mobile|telephone|number)\b/i]
};
function fieldText(f) {
  return [f.section, f.label, f.name, f.placeholder, f.autocomplete, f.type].filter(Boolean).join(" ").replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase().replace(/[_-]+/g, " ");
}
function typeCompatible(type, key) {
  const field = PROFILE_FIELDS.find((f) => f.key === key);
  if (!field) return false;
  const t = type.toLowerCase();
  if (t === "checkbox" || t === "radio") return false;
  if (t === "email") return key === "email";
  if (t === "tel") return key === "phone" || key === "emergencyContactPhone";
  if (t === "date" || t === "month" || t === "week") return field.kind === "date_static" || field.kind === "date_monotonic";
  if (t === "number" || t === "range") return !["name", "address", "text"].includes(field.kind);
  if (t === "textarea") return false;
  return true;
}
function heuristicKeyForField(f, vault, routedEntityId, entityWithKey) {
  const text = fieldText(f);
  if (isProtectedChoiceField(text)) return null;
  let best = null;
  for (const field of PROFILE_FIELDS) {
    const key = field.key;
    if (!typeCompatible(f.type, key)) continue;
    const eid = vault[routedEntityId]?.[key] ? routedEntityId : entityWithKey(key);
    if (!eid) continue;
    let score = 0;
    for (const re of FIELD_TEXT_HINTS[key] ?? []) {
      if (re.test(text)) score += 6;
    }
    const label = field.label.toLowerCase();
    if (text.includes(label)) score += 5;
    for (const alias of field.aliases) {
      if (text.includes(alias.toLowerCase())) score += 3;
    }
    if (field.category === "emergency" && /\bemergency\b/i.test(text)) score += 4;
    if (field.category === "immigration" && /\b(visa|uscis|i-?94|petition|immigration)\b/i.test(text)) score += 2;
    if (score > 0 && (!best || score > best.score)) best = { key, score };
  }
  if (!best || best.score < 3) return null;
  const entityId = vault[routedEntityId]?.[best.key] ? routedEntityId : entityWithKey(best.key);
  return entityId ? { key: best.key, entityId } : null;
}
function isProtectedChoiceField(text) {
  if (/\b(eeoc|self[-\s]?id|self[-\s]?identification|race|ethnicity|hispanic|latino|latinx|veteran|disability|sexual\s+orientation|transgender)\b/i.test(text)) return true;
  if (/\bgender\b/i.test(text) && !/\b(passport|identity|personal\s+details?|biographical|demographic)\b/i.test(text)) return true;
  return false;
}
function isReviewOnlyChoiceField(text) {
  if (isProtectedChoiceField(text)) return true;
  return /\b(work\s+authorization|legally\s+authorized|employment\s+eligibility|immigration\s+sponsorship|require\s+sponsorship|privacy\s+acknowledgement|sms|whatsapp)\b/i.test(text);
}
function canonicalOf(vault, entityId, key) {
  const record = vault[entityId]?.[key];
  const canonicalId = record?.canonicalId;
  return record?.candidates.find((c) => c.id === canonicalId)?.value ?? "";
}
function conflictedOf(vault, entityId, key) {
  const record = vault[entityId]?.[key];
  return !!record && record.conflictState !== "none";
}
async function matchFormFields(cfg, fields, vault, entities = []) {
  const matches = [];
  const unresolved = [];
  function entityWithKey(key) {
    if (vault["self"]?.[key]) return "self";
    for (const eid of Object.keys(vault)) {
      if (vault[eid]?.[key]) return eid;
    }
    return null;
  }
  for (const f of fields) {
    const routedEntityId = routeSectionToEntity(f.section, entities);
    if (isReviewOnlyChoiceField(fieldText(f))) {
      matches.push({ fieldId: f.id, profileKey: null, entityId: routedEntityId, confidence: "low", source: "heuristic", conflicted: false });
      continue;
    }
    const ac = f.autocomplete?.toLowerCase().trim();
    if (ac && AUTOCOMPLETE_MAP[ac]) {
      const key = AUTOCOMPLETE_MAP[ac];
      const eid = vault[routedEntityId]?.[key] ? routedEntityId : entityWithKey(key);
      if (eid) {
        matches.push({
          fieldId: f.id,
          profileKey: key,
          entityId: eid,
          confidence: "high",
          source: "heuristic",
          conflicted: conflictedOf(vault, eid, key)
        });
        continue;
      }
    }
    if (f.type === "email") {
      const eid = vault[routedEntityId]?.["email"] ? routedEntityId : entityWithKey("email");
      if (eid) {
        matches.push({
          fieldId: f.id,
          profileKey: "email",
          entityId: eid,
          confidence: "high",
          source: "heuristic",
          conflicted: conflictedOf(vault, eid, "email")
        });
        continue;
      }
    }
    if (f.type === "tel") {
      const eid = vault[routedEntityId]?.["phone"] ? routedEntityId : entityWithKey("phone");
      if (eid) {
        matches.push({
          fieldId: f.id,
          profileKey: "phone",
          entityId: eid,
          confidence: "high",
          source: "heuristic",
          conflicted: conflictedOf(vault, eid, "phone")
        });
        continue;
      }
    }
    const direct = heuristicKeyForField(f, vault, routedEntityId, entityWithKey);
    if (direct) {
      matches.push({
        fieldId: f.id,
        profileKey: direct.key,
        entityId: direct.entityId,
        confidence: "medium",
        source: "heuristic",
        conflicted: conflictedOf(vault, direct.entityId, direct.key)
      });
      continue;
    }
    unresolved.push({ field: f, entityId: routedEntityId });
  }
  const populated = Object.entries(vault).map(([eid, p]) => ({ eid, count: Object.keys(p).length })).sort((a, b) => b.count - a.count);
  const richest = populated.find((p) => p.count > 0)?.eid;
  if (richest) {
    for (const u of unresolved) {
      if (Object.keys(vault[u.entityId] ?? {}).length === 0) u.entityId = richest;
    }
  }
  if (unresolved.length === 0 || !cfg) {
    for (const u of unresolved) {
      matches.push({ fieldId: u.field.id, profileKey: null, entityId: u.entityId, confidence: "low", source: "heuristic", conflicted: false });
    }
    return matches;
  }
  const byEntity = /* @__PURE__ */ new Map();
  for (const u of unresolved) {
    const list = byEntity.get(u.entityId) ?? [];
    list.push(u);
    byEntity.set(u.entityId, list);
  }
  const entityLabel = (eid) => {
    const ent = entities.find((e) => e.id === eid);
    if (!ent) return eid === "self" ? "Self" : eid;
    return `${ent.name}${ent.relationship !== "self" ? ` (${ent.relationship})` : ""}`;
  };
  const blocks = [];
  for (const [eid, list] of byEntity) {
    const profile = vault[eid] ?? {};
    const available = Object.keys(profile);
    if (available.length === 0) continue;
    const profileLines = available.map((k) => {
      const label = PROFILE_FIELDS.find((f) => f.key === k)?.label ?? k;
      return `  - ${k} (${label}): "${canonicalOf(vault, eid, k)}"`;
    }).join("\n");
    const bySection = /* @__PURE__ */ new Map();
    for (const u of list) {
      const sec = u.field.section || "";
      const arr = bySection.get(sec) ?? [];
      arr.push(u.field);
      bySection.set(sec, arr);
    }
    const sectionBlocks = [];
    for (const [sec, arr] of bySection) {
      const header = sec ? `  SECTION: "${sec}"` : "  SECTION: (no section)";
      const lines = arr.map(
        (f) => `    - id="${f.id}"  label="${f.label}"  name="${f.name}"  type="${f.type}"  placeholder="${f.placeholder}"`
      ).join("\n");
      sectionBlocks.push(`${header}
${lines}`);
    }
    blocks.push(
      `ENTITY: ${entityLabel(eid)} [id=${eid}]
  PROFILE (key → label : value):
${profileLines}
  FIELDS TO MATCH (grouped by section):
${sectionBlocks.join("\n")}`
    );
  }
  for (const u of unresolved) {
    const profile = vault[u.entityId] ?? {};
    if (Object.keys(profile).length === 0) {
      matches.push({ fieldId: u.field.id, profileKey: null, entityId: u.entityId, confidence: "low", source: "llm", conflicted: false });
    }
  }
  if (blocks.length === 0) return matches;
  const prompt = `You are mapping web form fields to a user's profile data. Return JSON only — no prose.

Each ENTITY block below is one person in the vault. Within an entity, fields are grouped by SECTION (a fieldset legend or heading from the page) — that section context is your strongest hint for what each field is asking for.

${blocks.join("\n\n")}

For each form field, output { "id": "<field id>", "key": "<profile key>" or null, "confidence": "high"|"medium"|"low" }.

Matching rules:
- Match aggressively when the field clearly asks for a known profile value.
  Respect the input type:
    type="time"   → only time-of-day (HH:MM), NOT calendar dates
    type="date"   → only calendar dates
    type="email"  → only email-shaped values
    type="tel"    → only phone numbers
    type="number" / "range" → only numeric values
- If no profile key has a value with the right shape for the type, return null.
- Use the SECTION label to disambiguate. For example:
  - SECTION "Personal" → name fields map to fullName / firstName / lastName
  - SECTION "Emergency Contact" → name field → emergencyContactName, phone → emergencyContactPhone
  - SECTION "Spouse" → name → fullName *of the spouse entity*, dob → dateOfBirth *of the spouse entity*
- Common shortcuts:
  - "Customer name" / "Full name" → fullName
  - "Telephone" / "Phone number" / "Mobile" → phone
  - "E-mail address" → email
  - "ZIP" / "Postal" / "PIN code" → postalCode
  - "Street" / "Address line 1" → addressLine1
  - "DOB" / "Date of birth" / "Birthday" → dateOfBirth
- Use null for fields that genuinely don't map (radio choices, terms
  checkboxes, free-form notes, captcha tokens).
- Never invent profile keys outside the per-entity PROFILE lists above.

Return: { "matches": [ ... ] }`;
  try {
    console.log("[OctoVault matcher] LLM prompt:\n", prompt);
    const raw = await generateJson(cfg, { prompt });
    console.log("[OctoVault matcher] LLM raw response:", raw);
    const allowedByEntity = /* @__PURE__ */ new Map();
    for (const u of unresolved) {
      const keys = new Set(Object.keys(vault[u.entityId] ?? {}));
      allowedByEntity.set(u.entityId, keys);
    }
    if (!raw?.matches || !Array.isArray(raw.matches)) {
      console.warn("[OctoVault matcher] LLM returned no matches array");
      for (const u of unresolved) {
        matches.push({ fieldId: u.field.id, profileKey: null, entityId: u.entityId, confidence: "low", source: "llm", conflicted: false });
      }
      return matches;
    }
    for (const m of raw.matches) {
      const u = unresolved.find((u2) => u2.field.id === m.id);
      if (!u) continue;
      const allowed = allowedByEntity.get(u.entityId) ?? /* @__PURE__ */ new Set();
      const key = m.key && allowed.has(m.key) ? m.key : null;
      if (m.key && !key) {
        console.warn(`[OctoVault matcher] LLM returned unknown key "${m.key}" for field ${m.id} (entity ${u.entityId})`);
      }
      matches.push({
        fieldId: m.id,
        profileKey: key,
        entityId: u.entityId,
        confidence: m.confidence ?? "low",
        source: "llm",
        conflicted: key ? conflictedOf(vault, u.entityId, key) : false
      });
    }
    for (const u of unresolved) {
      if (!matches.some((m) => m.fieldId === u.field.id)) {
        matches.push({ fieldId: u.field.id, profileKey: null, entityId: u.entityId, confidence: "low", source: "llm", conflicted: false });
      }
    }
  } catch (err) {
    console.error("[OctoVault matcher] LLM call failed:", err);
    for (const u of unresolved) {
      matches.push({ fieldId: u.field.id, profileKey: null, entityId: u.entityId, confidence: "low", source: "llm", conflicted: false });
    }
  }
  return matches;
}

async function enrichDetection(cfg, fields, candidates) {
  const fieldsNeedingLabels = fields.filter((f) => !f.label || f.label.length < 2);
  if (fieldsNeedingLabels.length === 0 && candidates.length === 0) {
    return { corrections: {}, promotions: [] };
  }
  if (!cfg) return { corrections: {}, promotions: [] };
  const fieldLines = fieldsNeedingLabels.map(
    (f) => `  - id="${f.id}" type="${f.type}" name="${f.name}" placeholder="${f.placeholder}" section="${f.section ?? ""}"`
  ).join("\n");
  const candidateLines = candidates.map(
    (c) => `  - id="${c.id}" tag="${c.tag}" reason="${c.reason}" section="${c.section ?? ""}" text="${c.text.slice(0, 80)}"`
  ).join("\n");
  const prompt = `You help identify form fields on a web page that the DOM parser was uncertain about. Return JSON only.

DETECTED FIELDS WITH WEAK OR MISSING LABELS (suggest a better label using the type / name / placeholder / section if you can):
${fieldLines || "  (none)"}

SUSPICIOUS CANDIDATES (DOM elements that look form-like but weren't first-class inputs — decide if each is really a field; if yes, give it a label + a sensible HTML input type):
${candidateLines || "  (none)"}

Rules:
- Labels should be short noun-phrases ("Email address", "Date of birth", "Street").
- Types should be one of: text, email, tel, number, date, textarea, select, checkbox, radio.
- A candidate is a field only if a human filling the form would type a value into it. Decorative spans, action buttons, and structural containers are NOT fields.
- If you're not sure, leave the candidate out of promotions. Better to under-promote than to add noise.
- Never invent ids; reuse the exact ids shown above.

Return JSON of this shape:
{
  "corrections": [ { "id": "<field id>", "label": "<better label>" } ],
  "promotions":  [ { "id": "<candidate id>", "label": "<label>", "type": "<input type>" } ]
}`;
  try {
    const raw = await generateJson(cfg, { prompt });
    const corrections = {};
    for (const c of raw?.corrections ?? []) {
      if (!c?.id) continue;
      if (!fields.some((f) => f.id === c.id)) continue;
      if (c.label && c.label.trim().length >= 2) {
        corrections[c.id] = { label: c.label.trim() };
      }
    }
    const candidateIds = new Set(candidates.map((c) => c.id));
    const promotions = [];
    for (const p of raw?.promotions ?? []) {
      if (!p?.id || !candidateIds.has(p.id)) continue;
      if (!p.label || !p.type) continue;
      promotions.push({
        id: p.id,
        label: p.label.trim(),
        type: p.type.trim(),
        section: candidates.find((c) => c.id === p.id)?.section
      });
    }
    return { corrections, promotions };
  } catch (err) {
    console.warn("[OctoVault detect] enrichment failed; falling back to DOM-only:", err);
    return { corrections: {}, promotions: [] };
  }
}

async function fetchEntities() {
  try {
    const r = await fetch("http://127.0.0.1:53117/entities");
    if (r.ok) {
      const data = await r.json();
      if (Array.isArray(data) && data.length > 0) return data;
    }
  } catch {
  }
  try {
    return await indexedDbAdapter.listEntities();
  } catch (e) {
    if (e instanceof Error && e.message.includes("Vault is locked")) return [];
    throw e;
  }
}
const DESKTOP_OLLAMA_PROXY = "http://127.0.0.1:53117/ollama";
chrome.runtime.onInstalled.addListener(() => console.log("[OctoVault] installed"));
void chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch((err) => console.warn("[OctoVault] sidePanel setup failed:", err));
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handle(msg).then((data) => sendResponse({ ok: true, data })).catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
  return true;
});
async function cfg() {
  const s = await indexedDbAdapter.getSettings();
  const useBridge = await bridgeReachable();
  return {
    url: useBridge ? DESKTOP_OLLAMA_PROXY : s.ollamaUrl,
    llmModel: s.llmModel,
    embeddingModel: s.embeddingModel
  };
}
async function handle(msg) {
  switch (msg.type) {
    case "ping":
      return "pong";
    case "ollama.health":
      return { reachable: await isReachable(await cfg()) };
    case "ollama.generate":
      return msg.json ? generateJson(await cfg(), { prompt: msg.prompt, system: msg.system }) : generate(await cfg(), { prompt: msg.prompt, system: msg.system });
    case "form.match": {
      const remote = await fetchProfileFromBridge();
      let source = remote && Object.keys(remote).length > 0 ? "desktop" : "extension";
      let vault = remote ?? {};
      if (!remote || Object.keys(remote).length === 0) {
        try {
          vault = await indexedDbAdapter.getAllProfiles();
        } catch (e) {
          if (e instanceof Error && e.message.includes("Vault is locked")) {
            console.warn("[OctoVault] local vault locked; using bridge-only data");
            vault = remote ?? {};
          } else throw e;
        }
      }
      const entities = await fetchEntities();
      const llm = await cfg();
      const rawFields = msg.fields ?? [];
      const candidates = msg.candidates ?? [];
      const enrichment = await enrichDetection(llm, rawFields, candidates);
      const fields = rawFields.map((f) => {
        const c = enrichment.corrections[f.id];
        return c?.label ? { ...f, label: c.label } : f;
      });
      for (const p of enrichment.promotions) {
        fields.push({
          id: p.id,
          label: p.label,
          name: "",
          type: p.type,
          placeholder: "",
          autocomplete: "",
          section: p.section
        });
      }
      const matches = await matchFormFields(llm, fields, vault, entities);
      const intent = msg.intent ?? "";
      const fieldsById = new Map(fields.map((f) => [f.id, f]));
      const openFields = [];
      const fieldOptions = msg.fieldOptions ?? {};
      const fieldMaxLengths = msg.fieldMaxLengths ?? {};
      for (const m of matches) {
        if (m.profileKey) continue;
        const f = fieldsById.get(m.fieldId);
        if (!f) continue;
        const opts = fieldOptions[f.id];
        if (!isLikelyOpenField(f, !!opts?.length)) continue;
        openFields.push({
          field: f,
          options: opts,
          maxLength: fieldMaxLengths[f.id]
        });
      }
      const selfProfile = vault["self"] ?? {};
      const profileSummary = {};
      for (const [k, rec] of Object.entries(selfProfile)) {
        const cid = rec?.canonicalId;
        const value = rec?.candidates.find((c) => c.id === cid)?.value;
        if (["ssn", "passportNumber", "driversLicenseNumber", "nationalIdNumber", "taxIdNumber"].includes(k)) continue;
        if (value) profileSummary[k] = value;
      }
      let drafts = [];
      if (openFields.length > 0) {
        drafts = await generateFieldDrafts(llm, openFields, intent, profileSummary);
      }
      return { matches, vault, entities, source, fields, enrichment, drafts };
    }
    case "bridge.health":
      return { reachable: await bridgeReachable() };
    default:
      throw new Error(`Unknown message: ${msg.type}`);
  }
}
//# sourceMappingURL=index.ts-Daeamtml.js.map
