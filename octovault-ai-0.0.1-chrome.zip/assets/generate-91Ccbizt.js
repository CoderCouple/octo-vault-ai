import { g as generateJson } from './vault-crypto-BP82NYQF.js';

function isLikelyOpenField(f, hasOptions) {
  const text = `${f.section ?? ""} ${f.label ?? ""} ${f.name ?? ""} ${f.placeholder ?? ""}`.toLowerCase();
  if (/\b(eeoc|self[-\s]?id|self[-\s]?identification|gender|race|ethnicity|latinx|veteran|disability|sexual\s+orientation|transgender|arbitration|agreement|consent|acknowledge|certif(y|ication))\b/.test(text)) {
    return false;
  }
  if (f.type === "textarea") return true;
  if (hasOptions && (f.type === "radio" || f.type === "checkbox" || f.type === "select")) return true;
  if (f.type === "text") {
    const l = f.label?.trim() ?? "";
    if (l.endsWith("?")) return true;
    if (/\b(describe|explain|reason|details?|why|how|what|tell us)\b/i.test(l)) return true;
  }
  return false;
}
async function generateFieldDrafts(cfg, openFields, intent, profileSummary) {
  if (!cfg || openFields.length === 0) return [];
  const profileLines = Object.entries(profileSummary).filter(([, v]) => v && v.length > 0).map(([k, v]) => `  - ${k}: ${v}`).join("\n");
  const fieldBlocks = openFields.map((o) => {
    const f = o.field;
    const sec = f.section ? ` (section: "${f.section}")` : "";
    const max = o.maxLength ? ` (max ${o.maxLength} characters)` : "";
    const opts = o.options?.length ? `
    options:
${o.options.map((x) => `      - ${x}`).join("\n")}` : "";
    return `  - id="${f.id}" type="${f.type}" label="${f.label}"${sec}${max}${opts}`;
  }).join("\n");
  const prompt = `You are drafting answers to open-ended form fields on behalf of a user. Return JSON only.

USER INTENT (what they're filling this form out about):
${intent || "(none provided — keep drafts generic and clearly editable)"}

USER PROFILE (key → value — refer to where relevant):
${profileLines || "  (empty)"}

OPEN FIELDS NEEDING A DRAFT:
${fieldBlocks}

Rules:
- Free-text drafts (type="textarea" or "text"): write a first-person, concise, ready-to-submit paragraph. Use the intent + profile facts verbatim where they apply. Do NOT emit bracket placeholders like "[start date]", "[your name]", "[city]" — if a specific detail is unknown, write around it naturally ("I will be staying with family" not "I will be staying with [host]"). Stay within the character limit. Match the form's register (government form → formal; product feedback → casual).
- Choice drafts (type="radio", "checkbox", or "select"): pick exactly one of the supplied options that best fits the intent + profile. The draft string must equal one of the option strings character-for-character (whitespace-normalized).
- If the intent gives you no basis for the field, return an empty string and "confidence": "low" — the HUD will mark it for the user.
- Never include explanations, prefixes, quotes around the answer, or "Draft:" / "Answer:" labels. Output just the value.

Return JSON: { "drafts": [ { "id": "<field id>", "draft": "<text>", "reason": "<short note>", "confidence": "high"|"medium"|"low" } ] }`;
  try {
    const raw = await generateJson(cfg, { prompt });
    const out = [];
    const fieldsById = new Map(openFields.map((o) => [o.field.id, o]));
    for (const d of raw?.drafts ?? []) {
      if (!d?.id || !fieldsById.has(d.id)) continue;
      const draft = (d.draft ?? "").trim();
      const reason = (d.reason ?? "drafted from intent + profile").trim();
      const confidence = d.confidence ?? (draft ? "medium" : "low");
      out.push({ fieldId: d.id, draft, reason, confidence });
    }
    return out;
  } catch (err) {
    console.warn("[OctoVault generate] draft generation failed:", err);
    return [];
  }
}

export { generateFieldDrafts as g, isLikelyOpenField as i };
//# sourceMappingURL=generate-91Ccbizt.js.map
